# Playing NFS Underground 2 in the browser

The game runs in Google Chrome, Edge and the other Chromium browsers (Brave, Opera), in Firefox, and in Safari 26 (on a
Mac, or an iPhone or iPad with iOS 26 or iPadOS 26). One server hosts it: it keeps the game files, serves the game to the
browsers and connects players for free roam. On a Mac it serves that Mac; for other PCs it goes behind HTTPS, usually
on a VPS (`web/deploy/`). Nothing is installed on the players' PCs, and no file is picked by hand.

## 1. Start it (on the Mac)

```sh
web/start.sh            # or: cd web && npm start
```

- The first start takes longer: it installs the page's tools and builds what is missing (the game module, the page
  and the server; the server needs Rust, from https://rustup.rs). Later starts go straight to the server, unless
  the code changed.
- It looks for the game in `~/projects/nsfu2/Need for Speed - Underground 2`. If the game is somewhere else, start
  once with `web/start.sh --data "/path/to/the folder with SPEED2.EXE"`. The folder is remembered.
- The game folder is only read, never changed.
- It prints the address to open. `Ctrl-C` stops the server.

| Option | What it does |
|---|---|
| `--open` | Also opens the game in Chrome on this Mac. |
| `--http-port 9080` | Use another port, if 8080 is taken. |
| `--no-build` | Serve what is there, without checking the build. |

On the Mac itself, open **http://localhost:8080/** and press **Play** (or Enter).

The start page shows the download, then **Ready**. Play is on once the game module has loaded, which takes a second
or two. The page shows a problem only when there is one, with what to do about it.

## 2. Other PCs

The browser runs the game only on a secure page (`https://`, or `localhost` on the machine itself), so friends play
from a server behind HTTPS: a certificate on the server, or a proxy or tunnel in front of it (`web/deploy/` has a
Docker setup). Each player then opens that `https://` address in the latest **Google Chrome** or
**Firefox** and presses **Play**.

The first start on a PC downloads about 7 MB of game code and, while playing, the game data it needs, compressed on
the way. That PC keeps the data, so later starts are quick. To load it up front, press **Preload the game data** in
Game data on this device, at the end of the start page's Game tab (the button shows the size): about 2 GB (all but
the movies), a little over 1 GB over the network.
After that no loading screen waits on the network, which matters on a slow line to a remote server. The movies
stream from the server as they play; with Movies off (Game, Movies) the game never asks for them.

**Offline:** a PC that has opened the page once also starts the game when the server cannot be reached (no
network, or the server is down): the page keeps its own copy of itself and of the game code, updated each time the
server answers. The start page then says **Offline**, and the game runs from the game data on that PC, so download
it first. The movies are off for such a game unless every one of them is on the PC already. Free roam and Online
need the server; your saves are in the browser either way.

**Phones and tablets** (Chrome on Android, Safari on an iPhone or iPad with iOS 26 or iPadOS 26): a tap is a click, so
the game's menus work by touch, two fingers dragged sideways turn the car in the garage, and a finger dragged up or
down on a column of the ECU or Turbo tuning graph moves its dot. The ☰ button opens the page menu. On a phone the game
goes full screen when you press Play (an iPhone cannot: play it from the Home Screen, below) and renders at 75%
resolution scale (Game, Display changes both). After a few minutes of driving the page checks whether the phone
keeps its frame rate with GPU time to spare; if so, it renders at 100% from the next game on that phone (and goes back
to 75% if it later falls behind). This only applies while you leave the resolution scale at its default. A phone also
starts with lighter graphics: car and road reflections, motion blur, depth of field, overbright and bleach bypass are
off, which halves the GPU's work in a race (the game's Options, Display turns them back on). A phone that played
before gets them once, unless a graphics option was changed there. Held sideways, the game fills the screen with the
touch controls over it; held upright, it shows in a 4:5 picture at the top with the ☰ button and the touch controls
below it. The screen stays on while the game runs. Chrome's menu, **Add to Home screen** (or **Install app**), puts
the game on the home screen as an app that opens full screen; on a PC the same makes it an app with its own window. On
an iPhone it is Safari's Share menu, **Add to Home Screen**. On an iPhone or iPad that copy keeps its own saves: a
passphrase (Cloud saves) brings yours over. An app added from Chrome, on Android or a PC, shares the browser's saves.

**Touch controls** show on the game while you drive (races and free roam, in a race from the start line so you can
rev in the countdown). In the menus, the pause menu and free roam's cutscenes they give way to arrows, **OK** and
**Back** beside the game's menus (below the picture when the phone is upright); a tap on a menu still works too.
While you drive:

- **Right thumb:** Gas, Brake (and reverse), Nitro and the handbrake. A finger slides from Gas to Brake.
- **Steering**, switched with the button in the top right corner and kept in this browser: **buttons** (◀ ▶, as the
  arrow keys; the default), a **thumb stick** that appears where the left thumb lands, or **tilt**, the phone held like
  a wheel. With tilt, Brake and the handbrake move under the left thumb, and the button beside the switch sets
  straight ahead. That button held opens the touch settings (the Controls sheet's Touch tab) over the game.
- **Position**, in the Touch tab and kept in this browser: **Steering left** (the default) or **Steering right**, where
  the pedals go under the left thumb and the steering, the gear buttons and Start under the right (◀ ▶ stay in their
  order); either one **moved in**, 48 px further from the screen's sides, or **moved in more**, 112 px (upright, as
  far as there is room), for phones whose edges a thumb reaches badly. **Nitro on the steering side** (a switch
  there) puts Nitro under the thumb that is not on Gas: above the steering, with Start above Gas instead; with tilt,
  Nitro and the handbrake trade places.
- **Gears:** with a manual gearbox (the race's Transmission choice, and always in a drag race), gear down and gear up
  above the steering.
- **Small buttons** along the top: pause, camera (held: look back), reset (only while the car goes slower than about
  30 km/h, as when it is stuck or after a crash; its place stays empty at speed); in free roam also the map, messages,
  **Drift** (drift mode, the game's drift icon, lit while it is on), the career status (the game's Career Status, as
  D-pad Down on a controller, T or F4 on a keyboard), and the horn and quick chat (not with quick chat off)
  while another player's car is within a horn's reach. In a race with other players quick chat shows after reset
  (in landscape after Pressurize and Bounce, on a car with hydraulics), and on its results beside the menu's button.
  In free roam **Start** shows above the steering where it does
  something: at an event's or a shop's marker, at an outrun offer, or at a race spot or lobby of other players.
- **Hydraulics:** with a car that has them (the Hydraulics part, Car Specialties), **Pressurize** and **Bounce** join
  the small buttons (in free roam after the career status, upright in the second row; in a race after reset). A tap
  turns one on (lit, as H or J held on a keyboard), another tap turns it off, or the other one on. While one is on,
  the steering and Gas and Brake pick the corners instead of driving, under 10 mph as with H and J. Both show only
  while the car is that slow (or one is on): a second after it goes faster their places are empty, so the other
  buttons stay where they are.
- **HUD:** a phone starts with the game's 4:3 HUD layout (Game, Display, HUD layout), which keeps the minimap and
  the speedometer between the thumbs instead of under the steering and Brake.
- **Sizes**, in the Controls sheet's Touch tab and kept in this browser: **Control size** for the touch controls, and
  **Menu button size** for the game's own small menu buttons (Back, Continue and the others at the bottom of every
  menu, and the arrows of the main menu's and Quick Race's choices). Both are **Auto** by default: the touch controls
  at 100% on a phone and up to 125% on a tablet, as far as they fit; the arrows big enough for a finger, up to 200%,
  and the buttons at the bottom at the game's size (the touch controls' OK and Back do Continue and Back, and bigger
  they cover the menus' own things, such as the paint list). A size picked by hand makes those bigger too.
- A keyboard or a controller sends them away until you touch the game again. Android phones buzz on crashes.

## 3. Controls

| Key or button | What it does |
|---|---|
| Arrows or W A S D | Throttle, brake and reverse, steer |
| Alt | Nitrous |
| Space | Handbrake |
| Left Shift, left Ctrl | Gear up, gear down (manual gearbox) |
| C, B | Camera (the game's four views, then the drift races' camera, in every drive), look back |
| G | Headlights: a tap turns them off, or back on; held, high beam (brighter, reaching farther) until you let go. Friends in free roam see it, so you can flash your lights at them. On a controller the right stick straight up (see Controller below). Another key, or none, in Controls, Site |
| R | Respawn |
| H, J | Hydraulics, with the Hydraulics part (Car Specialties): hold H to pressurize or J to bounce, then the arrows pick the corners; under 10 mph; on a touch screen the Pressurize and Bounce buttons |
| N | Horn (free roam and races with other players) |
| X | Drift mode in free roam: drift handling, the drift camera and a drift score (see below); on a touch screen the Drift button, on a controller D-pad down held a second while driving |
| O | Parked in free roam: open the hood, then the trunk alone, then the doors alone, then all of them, then close them all (see section 6); on a controller hold D-pad down a second |
| 1 to 4, then 1 to 4 | Quick chat in free roam and in races with other players: a group, then a phrase (see section 6) |
| I | Message a friend in free roam: the answer to the newest message, or a friend to pick (see section 6, Friends) |
| M, Tab | Map, messages |
| T | Career status: what the stage still needs |
| Esc or P | Pause; Esc also goes back in menus |
| Enter | Choose (menus); in free roam, start an event at its marker or take an outrun |
| F12 | Photo mode while you drive (see below), and in it the photo; elsewhere a screenshot. Both are PNGs kept with your saves and shown in Saves on the start page |
| F10 | Hide the HUD while you drive, and show it again: the names and quick chat lines over other players' cars go with it; the pause menu, the map, messages and a race's results still show. Free roam and races; off again at each Play; no touch button. Another key, or none, in Controls, Site |
| **F7** | Next song: the game's next EA Trax song, or with Radio on the folder's next track (not while the game is paused) |
| **F8** | Frame-rate counter: off, on, detailed |
| **F9** | The page menu, a list with each item's state on the right: World (the one you are in), Tracks (the race tracks, in career free roam), Ghost mode (off, players, everything), Crews and Friends (in free roam; a lime dot on Friends while a request waits), Radio, Full screen, Controls (a page of the menu: ‹ goes back to the list) and **Quit game**, and Stop waiting: play offline while you wait in line; at the bottom when the game last saved, and Download log. Esc, F9, Close or a controller's B close it. On a controller Home, or both sticks pressed in; on a touch screen the ☰ button |
| **Hold Esc** | Leave full screen (a short press still goes to the game) |

The start page shows these keys under **Controls**, and F9, Controls shows them while you play.

- **Change the keys:** in the game, Options, Controls. It opens on Keyboard Configuration; Up to that title, then
  Right, is Joypad Configuration, the controller's buttons. The game lists a controller once it has seen it: press a
  button on it before opening Controls. A controller's buttons are kept with the profile (leaving Options saves them),
  the keys for every profile. The site's own keys and buttons (drift mode, the hood, trunk and doors, the horn, the
  headlights, the controller's free look, quick chat's controller button, messages, friends, photo mode, hiding the
  HUD, the page menu, the next song, the counter) are set on the start page, Controls, Site: click one, then press the
  new key or controller button, or pick Off (the page menu always has a key, and Home); the free look's Auto or Off
  switches with a click. Keys the game itself uses can't be picked; one of the game's controls you put on one of
  the site's keys in the game's Controls takes it: the site's control leaves it to the game, and Site says so. D-pad
  down and the stick clicks with the game's own controls on them as it comes (Career Status, hydraulics) are shared as
  before: a short press, and a car with hydraulics, stay the game's. The touch controls' Drift and Horn work whatever
  keys those have.
- **Drift mode (X):** in free roam, the car handles as in the game's drift races (their handling and drift assist,
  with your car's Drift tuning from Performance Tuning / Dyno in the crib; the other modes' tuning is back when drift
  mode is off), but your nitrous stays (the drift races have none; X neither empties nor fills it). The camera is the
  drift races' (C still goes through all of them), and drifts score as there: the drift races' panel (Best, the
  multiplier with the points its next level needs, Total) shows under Bank, and DRIFT counts a drift's points up
  while you drift, as in the races: lime when it banks, red when a wall loses it. Free roam's
  music plays on (the drift races have none, unless Music in drag and drift races is on in the start page's Game).
  Just for fun: the points never go into the bank or the career. X again turns it off and gives your camera back. It is off in
  races and outruns and comes back in free roam after them.
  With it on, challenging another player is a drift battle (see section 6, Drift battles).
- **Photo mode (F12, or Photo Mode in the pause menu):** while you drive (a race, free roam, an outrun) the world
  stands still, the HUD goes and the camera comes loose from the car. Orbit (the first) turns around a point at your
  car, which you can move up to 25 m from it, from up to 30 m away; Free flies up to 50 m from the car. Drag with the
  mouse (or the arrow keys) to turn, W A S D to move, Q and E for down and up, the wheel to come closer or go farther,
  Z and X to zoom, C and V to tilt, Shift to go faster, Tab for orbit or free, R to start over, N for the names over
  other players' cars (free roam only; off at first), H to hide the panel. F12, Enter or Space takes the photo, Esc
  leaves. On a controller: the right stick turns, the left stick moves, LB and RB are down and up, the triggers closer
  and farther, the D-pad zooms and tilts, Y is orbit or free, X starts over, a click of the right stick is the names,
  A takes the photo, B leaves, View hides the panel. On a touch screen: drag to turn, two fingers to move, pinch for
  closer or farther, the panel's buttons for the rest. The sound effects pause, the music plays on. In free roam with
  other players your world stands still for you only: they see you as paused and drive through you. Not in races over
  the network (Online, LAN, free roam's races with other players). Nothing keeps the camera out of walls.
- **Mouse:** works in the menus; in the garage, drag with the middle button (the wheel) held to turn the car, as in
  the PC game. On the ECU and Turbo tuning graphs the wheel moves the dot of the column under the pointer, as in the
  PC game, and so does a drag up or down on that column. **Touch:** a tap is a click there; drag two fingers to turn
  the car; drag one finger up or down on a tuning graph's column.
- **Controller:** an Xbox or PlayStation pad works through the browser. Its buttons go by their place, named here as
  on an Xbox pad: A is the bottom one (Cross on a PlayStation pad, B on a Nintendo-style pad such as most 8BitDo
  ones). The browser shows a pad to the page only after a button is pressed on it. The triggers are throttle and
  brake, the left stick steers, LB is nitrous, RB the handbrake, A and X shift, Y and B are camera and look back, View
  respawns, Start pauses; D-pad up starts an event or takes an outrun, left and right are the map and messages, down
  is Career Status (in free roam, held a second: drift mode while driving, the hood, trunk and doors parked). A
  click of the left stick is the horn, unless your car has hydraulics: then the stick clicks are the game's hydraulics
  (left: pressurize, right: bounce). While driving (free roam, races, races with other players) the right stick
  looks round the car: the view turns to where it points (right looks right, half way out half as far) and swings
  back behind the car when you let go; with the bumper and hood cameras it turns on the spot. Straight down is the
  game's own look back, as B (whatever button you bound to it). If you steer, accelerate or brake with the right
  stick (the game's Options, Controls, Joypad Configuration), the left stick looks round instead, as long as the game
  uses nothing of it (no steering or pedal, no direction bound to a control); if it does, neither stick looks round.
  The stick that looks round, pushed straight up, is the headlights (G): a flick up turns them off or back on, held up
  is high beam until you let go. For the original camera, Controls, Site, Free look: Off (a click on its Auto) turns
  the look off: no stick looks round, straight back is no look back (B still is), and stick up no longer switches the
  headlights (G still does).
  In free roam and in races with other players a click of the right stick is quick chat, hydraulics or not (J still
  bounces): it shows the four groups, a flick picks one, another its phrase, and a second click closes it. With the
  right stick steering or on a pedal, its click stays the game's (bounce), and 1 to 4 open quick chat. In the
  garage, the shops and the main menu the right stick turns the car round and tilts the view, as the middle-button
  drag does: right turns the view right, as in photo mode (and as a drag to the right), down looks down on the car;
  full stick turns about 60° a second. Each screen starts at the game's own angle.
- **Steam Controller, Steam Deck:** Valve's controllers are no game controllers to the browser (without Steam they act
  as a mouse and a keyboard). In Chrome or Edge on a computer, Controls, Controller, **Connect a Steam Controller**
  opens the browser's list: pick it once, and while you play it is a controller, its buttons where an Xbox pad has
  them. That works for both Steam Controllers (the 2015 one on its cable or dongle, the 2026 one on its cable, dongle or
  Bluetooth) and a Steam Deck's controls. The 2015 controller's right pad is the right stick (where your thumb is on
  it), its left pad's clicks the D-pad. While the game is in front it is no mouse; switch away from the tab or the
  window and it is one again. The 2026 controller and the Deck rumble. In Firefox and Safari: add the browser to Steam
  as a non-Steam game with a gamepad layout and start it through Steam.
- **Steering wheel:** a Logitech G29, G920 or G923, and other wheels the browser shows as a game controller. The wheel
  steers, the pedals are throttle and brake (and reverse), the paddles shift down and up, Cross (A) is nitrous, Square
  (X) the handbrake, Circle and Triangle (B and Y) look back and camera, Share respawns, Options pauses, PS opens the
  page menu; the red dial and Enter work the menus. The game gets a wheel, as the PC game did with one: the car's
  wheels follow yours, with no delay. Full lock is 135° each way (270° from lock to lock), not the wheel's whole 900°;
  on a wheel the page does not know, it is the wheel's own full turn. No browser maps a wheel, so the page takes the
  layout of a Logitech G29, G920, G923, G25, G27 or Driving Force GT from what is known of that model (the G29's gas,
  brake and clutch are its Z, Rz and Y axes, the G920's Y, Z and Rz), as Chrome, Firefox and Safari each place those
  axes, and guesses any other wheel's from how it reports itself. If steering or a pedal is wrong, or you want another
  full lock, open Controls, Controller and press Set up the wheel: turn it to where full lock should be (a quarter
  turn suits this game), then press each pedal. That is kept in this browser. The clutch does nothing (the game has
  none). A browser cannot drive a wheel's motor: no force feedback.
- **Shifter:** the game's gearbox shifts one gear at a time, so a shifter (the Driving Force Shifter on a G29, G920
  or G923 for PlayStation, the G25's and G27's own) works as a sequential one: each move of the lever into 1st, 3rd
  or 5th shifts up, into 2nd, 4th or 6th down, and the lever goes back through neutral for the next shift; in reverse
  it holds the handbrake. The paddles still shift. Controls, Controller, Shifter can turn it round (pull to shift
  up), make every gear the handbrake, or turn it off; that is kept in this browser per wheel model. The Driving Force
  GT's own shifter shifts up when pulled back, down when pushed.
- **RC radio:** a drone or model transmitter running EdgeTX or OpenTX (a RadioMaster, FrSky or Jumper, for example),
  plugged in by USB in its joystick mode, drives as a wheel: the right stick across steers (full stick is full
  lock), the throttle stick is the gas and the right stick pulled back brakes and reverses. That assumes mode 2 and
  the usual channel order (AETR); Controls, Controller, Set up the radio takes any other: push the stick that steers
  right, the gas stick up, the brake stick back, then flip a switch (or hold a button) for nitrous, the handbrake and
  a respawn, or skip each. Its switches do nothing until then. The keyboard does the rest (menus, camera, pause).
  With a controller connected too, a stick or switch on the radio moved half way takes the game back from it.
- **The page menu on a controller:** Home, or both sticks pressed in, opens it (where the browser passes Home on; on
  Windows the Game Bar may take it). The D-pad or left stick moves in it, A picks, B closes it; meanwhile the game
  gets no controller input. A stick pressed in alone reaches the game a moment later (0.12 s), so the shortcut never
  honks or works the hydraulics.
- **Split screen:** the main menu's item after Quick Race. Pick 2, 3 or 4 players and the race, then each player
  presses START on their own controller and picks a car. Every player gets their own view, HUD, minimap and camera;
  player 1's controller works the results and Post Race menu. Each view is a whole scene, so 3 or 4 players need a
  fast computer. It is BirdSentinel (Zack)'s port of mihaits'
  [NFSU2-SplitScreen](https://github.com/mihaits/NFSU2-SplitScreen).
- **Two players on one keyboard** (split screen): one presses Enter to join, the other Space. Alone on the keyboard,
  a player has all of it (arrows or WASD, Shift nitrous, Space handbrake, E and Q gears, C camera, B look back).
  With two, the keyboard is shared:

  | | Enter's player | Space's player |
  |---|---|---|
  | Steer, gas, brake | arrows | A and D, W, S |
  | Nitrous | Right Shift | Left Shift |
  | Handbrake | Right Ctrl or / | Space |
  | Gear up, gear down | . and , | E and Q |
  | Camera, look back | L and ; | C and B |

  These keys stay as they are (Options, Controls does not change them). Many laptop and cheap keyboards cannot see
  every key two players hold at once: a key can drop out for a moment. Gaming keyboards can.
- **A second player in your career's free roam:** pause in free roam and pick Add Player 2. Player 2 presses START on
  a controller, or picks Keyboard to drive on the keyboard's left half (the Space player's keys above; player 1 keeps
  the arrows). Then pick the car player 2 drives from your garage (Next car, Drive); both of you may drive the same
  car. The city loads once and player 2 starts behind you, the screen split in two, each half with its own HUD and
  map. Remove Player 2 in the pause menu lets them go.
  - Player 2 is a guest: nothing of theirs is saved. Only player 1 starts races, shops and story events; the money,
    messages, GPS and world map are player 1's.
  - A career race asks first: Together (player 2 races as one more rival; only player 1's place counts for the
    career, and the race ends when both are home) or Alone (player 2 waits and is back beside you after it).
  - Outruns between the two of you: drive close together for a few seconds, then either one presses Engage. They
    win nothing and cost nothing.
  - Online, other players see player 2 under your name and " 2". Player 2 takes half of Online, Players' cars shown.
  - Drift mode (X) is off while player 2 is in.
  - On computers only (not on phones and tablets; `coop = off` in settings.ini turns it off). Two views take a faster
    computer.
- **Rumble:** a controller that can rumble in Chrome (Xbox, DualSense and others) shakes when you crash, scrape a
  wall or land hard. Controls, Controller, Rumble turns it off. Firefox has no rumble.
- **Sound** starts with the Play click. If the browser still keeps it off, a note says so, and a click on the game or
  a key press turns it on. A controller button cannot: the browser does not count it.
- **Firefox and Safari:** Esc leaves full screen at once (they have no keyboard lock); in full screen, pause with P.
- **Quit** from the game's main menu, or with F9, Quit game. Both let the game save and close. When the game saved
  nothing in the last 10 minutes (or nothing yet in this game), F9's Quit game asks first and says how to save: stop
  the car, press Esc and choose Save. If a loading screen
  ignores the request, the same menu item then reads "Close the game now". As a last resort it reads "Stop the
  game". Closing the tab asks first, because a save in progress could be cut short.

## 4. Settings

The start page's big panel has six tabs: **Saves**, **Online**, **Friends & crews**, **Game**, **Mods** and
**Controls**. Online, the crews, Game, Mods and the Controller part of Controls hold this browser's `settings.ini`,
the same file and keys as the Mac app; Game ends with the game data on this device, the file as text and Reset all
settings. Each change is saved at once and applies the next time you press Play. Under Play, **Playing now** shows how
many play on this server now: in total, in free roam, and in the game's Online mode (its races and lobbies); the
World row's list says how many are in each world.

| Where | Settings |
|---|---|
| Online | free roam with others, your name (in free roam and online), your flag, license plate (up to 8 letters and digits on your car, also for other players in free roam), your horn, world (Main world, World 1 to 4, or a name of your own), blocked players; more: ghost mode (off, players or everything), players' cars shown (16, 24, 32, 48 or 64, and on a computer Auto, its default: 32, more while the frame rate allows; phones start at 16, tablets at 24), quick chat and your phrases, the game's Online mode (on by default) |
| Friends & crews | crews (with their colours), and your friends (once your name is claimed) |
| Game, Game | language, movies, music in drag and drift races, autosave; more: startup movies (skippable, original or off), sound, pause or keep running in the background, sound output latency, highest graphics for a new save |
| Game, Display | full screen on Play (off: the game plays in the browser window; on by default on phones), resolution scale (phones start at 75%, 100% once one shows it has the room), frame rate (auto picks 30, 60, 120 or 240 from the screen: 120 from 119 Hz, 240 from 239 Hz, otherwise 60, so a 75 Hz or 144 Hz screen gets 60 or 120; or 30, 60, 120 or 240, where 30 keeps a phone that cannot hold 60 steady; Online and LAN races at most 120); more: pixelated textures (off), HUD layout (wide, or 4:3 as phones start), movie framing, cutscene bars, 3D proportions (original, as the game drew them about 10 % too wide, or corrected: round wheels, a little more at the sides), other cars' headlights (players, all cars, off), frame-rate counter, fixed render size, pixel limit |
| Mods | the mods built in, with their makers (the (i) after a row's name says what it does, who sees it, where it is set and its pages), and the settings of those that have one: Upscaled HUD and Detailed Map (original, map only or upscaled), English Subtitles Fixed (the subtitles), Uncensored & Restored Soundtrack (the songs: uncensored or original), GPS Distance, Show Hidden Races, Visual Reputation Remover, Mods on other cars (shown or original), Stance, Crash Damage, Rubberbanding (original, no boost or off), Transmission Whine, HQ Vinyls & Doorlines; and our changes from the original game, a row per group (Driving, Free roam, Photos and screen, Career and garage, Controls, Saves), whose (i) lists them all |
| Controls, Controller | rumble; more: controller (on, hotplug or off), menu buttons, dead zones, trigger full press |

- **Language:** English, French, German, Italian, Spanish, Dutch, Swedish, Danish, Korean, Chinese, Japanese, Russian,
  Thai, Portuguese (Brazil), Polish, Turkish, Hungarian, Ukrainian, Czech, Slovak or Greek, for the menus and all the
  game's text. Where the server has the language packs, French, German, Italian, Spanish, Japanese and Russian also play
  with their dubbed voices and movies, Chinese, Japanese and Thai with their full text, and Russian, Portuguese, Polish,
  Turkish, Hungarian, Ukrainian, Czech, Slovak and Greek with their text at all. Without the packs those nine play in English, and the other
  languages with English voices and movies. Your browser fetches only your language's files: the dubbed voices are
  about 50 MB (Russian 94 MB), and the dubbed movies are smaller than the English ones they replace. Hungarian's
  text writes ő and ű as õ and û, as its translation does: the game's fonts have no ő or ű. Czech's writes č, ř, š and
  the other letters with the caron as c, r, s ..., as its translation does, for the same reason; Slovak's has every
  letter, with the fonts its translation brings, and Greek's with Greek letters added to the game's fonts. The start
  page follows the
  same choice (the list at its top sets it too): its text, settings and messages in that language, English until you
  pick another.
  Its problems and errors carry a short code (`GPU-ADAPTER-WIN`), the same in every language, to quote when you ask
  for help; the log stays English.
- **Mods:** the Mods tab lists the community mods this game carries, under On your screen, Seen by others and Game
  rules, each with its makers as its mod page names them, then Our changes, where this site differs from the original
  game. A row with a setting has its switch or choice. The (i) after a row's name opens what the mod does, who sees it,
  where it is set, what this game takes from it and its pages; Our changes has a row per group (Driving, Free roam,
  Photos and screen, Career and garage, Controls, Saves), whose (i) lists every change in it, with its key.
- **Subtitles** (Mods, English Subtitles Fixed): on by default: the movies' lines as text (the PSA, the tutorials and
  the story) in every language but French, German, Italian and Spanish, whose movies are dubbed. English's are
  VileStuff's [English Subtitles Fixed](https://nfsmods.xyz/mod/5286), with who says each line, where the server has
  its language pack (without it English has none: the game's own English lines stop at their first apostrophe). Off,
  no language has subtitles.
- **Songs** (Mods, Uncensored & Restored Soundtrack): the EA Trax songs. Uncensored (the default) plays them unedited,
  some in longer versions than the game's, as xGMVx's [Uncensored & Restored Soundtrack](https://nfsmods.xyz/mod/3649)
  has them. Original plays the versions the game shipped with, where the server has them. F7 skips to the next song
  while you play.
- **Music in drag and drift races** (Game): off by default: as in the original game, those races have no
  music, so you hear the engine for the shifts. On, the EA Trax songs (or the Radio's tracks) play there too, as in
  the other races, at the game's music volume, in every drag and drift race: the career's, Quick Race, LAN and Online.
- **Show Hidden Races** (Mods): off by default. The career has 33 hidden races (one in the prologue, then 4, 8, 10
  and 10 in the later stages) that are not on the map or the radar: in the original game one shows only when you drive
  near it, and once all the others are won the map looks empty. On, as MaxHwoy's [Show Hidden Races
  Mod](https://nfsmods.xyz/mod/1583) has them, they are on the map and the radar like the others (the GPS takes you
  there), and the map offers up to 8 races of each kind at once instead of 1 to 4, so they take no others off it.
  Turned off again, a career is as it was: the races open stay open.
- **Visual Reputation Remover** (Mods): off by default. In the original game a stage's DVD cover shoots come only once
  your car's visual parts rate enough stars, and a shoot pays more for more stars. On, as thelink2012's [Visual
  Reputation Remover](https://nfsmods.xyz/mod/2773) has it, the rating is the stage's (none in the prologue, 1, 3, 5.5
  and 8 stars in stages 1 to 4, 10 from stage 5), so every cover shoot of the stage is offered the next time free roam
  loads, and pays by that rating. The shops show no Visual Rating box. Turned off again, the next free-roam load
  offers the shoots by your car's own rating; the ones shot and paid stay.
- **Stance** (Mods): off by default. On, as Archie (AR4I)'s [Stance Mod](https://nfsmods.xyz/mod/1687) has it but for
  each car of yours: the garage's Body Shop gets a Stance entry after Rims, a page of sliders with the car behind it:
  Front Camber and Rear Camber (0 to 15 degrees, the wheels' tops in; the front starts at the camber the game gives
  your suspension parts), Front Offset and Rear Offset (-40 to +80 mm, the wheels further out or in) and Tire Width
  (80% to 130%). Looks only: the car drives as in the original game. In free roam other players see your car's stance.
  It is kept beside the profile (MODPARTS.DAT): the profile still loads in the PC game, where the car looks as the game
  draws it. Off, your cars look as in the original game and the Stance entry is gone; the values stay for later.
- **Mods on other cars** (Mods, the first row of Seen by others): Shown by default. Original draws other players' cars
  as the original game does, without the stance they set.
- **Crash Damage** (Mods): off by default. Chrystian Farias's Crashing Foreign Cars: the racers' cars, yours and the
  AI's, dent where they are hit, scratch, break their lights and lose loose parts, which lie on the road for a while.
  Looks only: the cars drive as in the original game. In free roam, players who have it on see each other's damage;
  with it off you see every car undamaged and yours is shown undamaged to everyone. The game's own repair (a race's
  start, the garage) takes it away. Its scratches are a download of about 1 MB, fetched only when it is on.
- **Rubberbanding** (Mods): Original by default. In a career race the game slows the opponents who are ahead of you
  and gives the ones behind you more power, grip and top speed, more the farther back they are: up to 22% to 37%
  (more for a better driver) at 320 m behind, while one 320 m ahead of you drives 10% to 15% slower. No boost keeps
  the waiting but never lets an opponent behind beat its own pace; Off drops both, as a Quick Race with Catch Up off.
  Only your own career races: Quick Race keeps its own Catch Up option, and LAN and online races have no computer
  opponents.
- **Transmission Whine** (Mods): off by default. On, as ropi's
  [Underground 2 Transmission Whine](https://nfsmods.xyz/mod/5927) has it, your car gets NFS Carbon's gearbox whine
  (the BMW M3 GTR's, the mod's sounds) over the game's sound: a whine rising with your speed and gear, a second layer
  louder the faster you go, a short pause at each upshift and a whine of its own in reverse. Every car has it (in split
  screen and co-op each player's), as loud as the game's Engine Volume (times Master) makes it; the world paused, it
  is silent. Its sounds (half a megabyte) download once it is on.
- **HQ Vinyls & Doorlines** (Mods): on by default on a computer (off by default before the update after 8 November's). On, as AdrienShadow's
  [High Quality Vinyls & Doorlines](https://nfsmods.xyz/mod/8064) has them, every car's paint is drawn again at
  1024x1024 from the mod's vinyls and doorlines, twice the game's size: the same designs, colours and shine, sharper
  up close (the garage, the shops, photo mode). Only on your screen, on a computer (a phone keeps the game's). A car
  with one of Art Factory 28 to 34, which are not the mod's, keeps the game's look. Each car's pictures download as
  you see it, about 100 KB; offline, the cars keep the game's look.
- **Upscaled HUD and Detailed Map** (Mods): Original (the default) is the game's own. Upscaled shows LunicAura106's
  [Upscaled HUD](https://nfsmods.xyz/mod/4319) and JeansBig's [Detailed Map](https://nfsmods.xyz/mod/4485) where the
  server has their texture packs: the menus, the race HUD, the fonts and the car and brand logos redrawn at four times
  their size, and the minimap's, world map's and race menus' maps at 2048x2048, with the missing shortcuts, and
  shortcuts and off-road in their own colour. Map only shows the Detailed Map alone, with the game's own menus and
  HUD. The game's layout stays as it is. Your browser fetches the packs only with Map only (about 20 MB) or Upscaled
  (about 25 MB in all; the maps as the game loads them). A language with fonts of its own (Russian, Polish, Turkish,
  Chinese, Japanese, Thai) keeps them. Most phones decode the larger textures into four times the memory.
- **Radio:** the menu (F9) has a Radio line. It plays the music files of a folder on your device in place of the
  game's EA Trax songs. The folder icon picks the folder, its subfolders included; the list icon opens the Playlist:
  each track is Menu, Race, All or Off, and **Shuffle** plays them in random order. A new song starts with the next
  track that suits the place, and the game's plaque shows its artist, title and album (the tags of an mp3, else the
  file name, else the subfolder's name). A file that cannot be read is skipped. The files stay on your device. The
  folder and the switch are remembered; after a reload the browser may ask for access to the folder again, then click
  the Radio line. Firefox and Safari on a Mac pick the folder too, but cannot remember it: pick it again after a
  reload. On an iPhone or iPad the menu has no Radio line: Safari there cannot pick a folder. Radio off leaves the
  game's EA Trax as it is.
- **More settings:** each group's "More … settings" has the less common ones, and says how many of them you
  changed. **Reset** next to a changed setting puts its default back.
- **Edit the file:** "Edit settings.ini as text" opens the file itself. A line the game would ignore is shown with
  the reason. A line that sets a runtime variable by its own name (`NFSU2_ROAM = 1`) shows on the row it belongs to.
  "Other settings in this file" lists every line the page has no control for: such variables, and the settings it
  does not show (`roam_rate` and the other free-roam network settings). Lines that would name a file of your saves or
  drive the game by itself (`NFSU2_REGFILE`, `NFSU2_INPUT_SCRIPT`, ...) are ignored: only the page sets those.
- **Links:** settings in a page address (`?env=...`) work only on a development server (one started with `--dev`).
  On yours a link cannot change your game; the start page says so when an address carries them.
- **The look:** the game looks as it did originally. Any graphics enhancement will be a separate setting, off
  unless you turn it on. One fix is always on: a car's shadow lies 1.5 cm above the road instead of 4, so its edge
  no longer cuts into the bottom of the tyres (TerminatorVasya's [NFSU2 Shadow Fix](https://nfsmods.xyz/mod/7328)).
- **The European cars:** the Peugeot 106 and the Vauxhall Corsa 1.8, which only the European release sold, are in the
  car lot and on every car select (Quick Race, Customize, LAN and Online), and AI racers drive them too. The North
  American game has their files but hid them. This, the Special vinyls and Quick Race below, the drift camera (C) and
  high beam (G) follow the ExOpts Team's [NFSU2 Extra Options](https://nfsmods.xyz/mod/290).
- **The garage:** the career keeps up to 10 cars, not 5. A new career opens 2 slots and each stage 2 more (10 from
  stage 5); a career from before, or from the PC game, gets 2 for each stage it has reached when it loads. Trade Car
  on the crib's car list (C, or tap it) takes a car away for 80 % of what you spent on it, as the game's own trade-in
  question says, when you have two cars or more. The car lot's cars are free, so that is 80 % of the parts. Slots 6 to
  10 are kept in a file beside the profile, which backups, cloud saves and Rename carry along. The PC game loads the
  profile with its first 5 cars, driving the first one when yours was one of the other 5. A profile changed
  elsewhere (played in the PC game) loads here with its 5 too: the other 5 are kept aside in the profile's folder,
  as `GARAGE.OLD`.
- **Unique parts after Caleb:** the outruns' unique visual parts (the wide body kits, and the unique hoods, spoilers,
  rims and vinyls) go, as in the original game, to the one car you drive to their star, and the wide body's star
  (11 outrun wins in stage 5) comes only before the last URL race. Once you have beaten Caleb, the shops have all of
  them for every car in your career, as the original game's ending has them in Customize mode, whose cars free roam
  never drives. The unique performance parts stay one per stage.
- **Special vinyls:** the Graphics Shop's vinyls have a Special category after Sponsor, with the game's promo vinyls
  (Snoop Dogg, Capone, Chingy, The Doors, David Choe, D3, Japan Tuning, Shinestreet, Street Reaper), for the cars that
  have them. The game hid them. They are free, open at the stages the game gives them (2 and 3), and add nothing to
  the visual rating.
- **Quick Race:** Laps go from 1 to 127 and Opponents up to 5 in every race but drags, which keep the game's 3. With
  Lap KO on, both can still be changed: it starts at 5 laps and 5 opponents, with at least 1 opponent. In every
  race, a race of one lap shows Completed and a percent in place of LAP 1/1, as sprints do.
- **Power Units:** the game's Options, Gameplay (also in the pause menu's) has a row after Speedometer Units: the
  engine's power in bhp or kW wherever the game shows it (the dyno, the performance shop's parts), whatever the
  speedometer shows. Until you change it, it follows Speedometer Units, as in the original game (kW with km/h).
  Torque still follows the speedometer (Nm with km/h, ft-lbs with mph), and the dyno results' 0-60 and 0-100 are
  mph times either way.
- **Show Player Names:** the game's Options, Gameplay (also in the pause menu's) has the game's own Show Player Names
  row before Save, which the original game has only in a LAN lobby's options. Off hides the names over other players'
  cars, in free roam and in LAN races; On, the default, shows them. It stays with the game's options on this device
  (backups carry it, cloud saves do not).
- **The Bank in free roam:** the Bank box at the top right of career free roam shows only while it has something to
  say: for 20 s after your bank changes (a race's or an outrun's prize, a purchase, a money icon), for 10 s when free
  roam starts, and for 8 s after the pause menu, the map or a shop. In the original game it is always there. The
  magazine and DVD cover rewards show as before.
- **The box at the top left in free roam:** the box with the D-pad and its icons (the envelope of an SMS waiting,
  Engage, an outrun) shows the same way: for 20 s after a new message, while your car is at a race marker, a shop's
  door or an outrun's tuner, for 10 s when free roam starts, and for 8 s after the pause menu, the map or a shop. In the
  original game it is always there.
- **Exposure and White Level:** for eyes that a bright picture tires. The game's Options, Display (also the pause
  menu's) has two sliders after Level Of Detail. Exposure makes the whole picture darker or brighter, from half to
  twice as bright (the middle, the default, is the game's own). White Level is the brightest the picture gets, from
  40 % to 100 % (the default): only the brightest parts come down, so dark streets stay as they are. Both change the
  picture as you move them, the menus and the HUD too, and stay with the game's options on this device (backups
  carry them, cloud saves do not). F12 screenshots keep the game's own colours.
- **Anti-aliasing:** the game's own Full Scene Anti-Aliasing, in its Options, Display, Customize Display Settings
  (also the pause menu's), drawn at 4 samples: smoother edges, for more of the graphics' work, so a slower computer
  may lose frame rate with it. A new player on a computer starts with it on; a computer that played before is asked
  once at Play ("Smoother edges?"). Phones are not offered it, tablets start with it off, and computers with AMD's
  Vega (GCN-5) or Qualcomm graphics are not offered it (it lost their graphics). settings.ini `fsaa = off` greys the
  option out.
- **Anisotropic filtering:** roads, their lines and building fronts stay sharp at a distance and at an angle, which
  the original game never had. On for computers, off on phones and tablets; settings.ini `anisotropic = off` turns it
  off.
- **Two tabs:** one browser runs one game at a time. A second tab shows "Open elsewhere" and its Settings are
  read only. It takes over when the first tab closes.

## 5. Saves

- **Where they are:** your profiles and career are saved **in this browser, on this PC** (the site storage for
  the server's address). They are not on the server, unless you use cloud saves (below). Each address keeps its own
  save store, so stick to one.
- **Cloud saves:** Enable cloud saving (in Saves, beside Cloud saves) keeps your saves on the server too, under a
  passphrase only you have (it was called a keyphrase before): `nfsu2-xyz-` and 8 words. In another browser (another
  PC, a phone), enter it in the box and press Load: any case, with or without `nfsu2-xyz`. There is no account and no
  email. Until you have them, Play asks to turn them on once you have a profile (again a week after each Not now,
  three times at most): it shows your profiles, their money and the hours played in this browser, and Download backup
  there keeps a file of them instead.
  - The page locks the saves with the passphrase before they leave the browser: the server keeps bytes it cannot
    read, under a code made from the passphrase. Keep the passphrase safe, in a password manager say: it is the only
    way back to these saves, and nobody can look it up for you. The box shows its first 3 characters; the eye shows
    all of it and copies it, the arrow downloads it as a file.
  - **In your browser's passwords:** Chrome, Edge and the other Chromium browsers offer to save the passphrase with
    your passwords (user name "Cloud saves") when it is made or loaded: choose Save. Unlike the saves, the browser's
    passwords stay when this site's data is cleared, and your other devices may get them too. A browser with no
    profile and no cloud saves then asks the browser for it as the page opens (Chrome shows its own "Cloud saves"
    chooser, once; nothing if it has none) and offers those saves. Every browser's password manager also fills the
    passphrase into the box, ready for Load. Firefox and Safari offer to save a passphrase you typed or pasted there
    for Load; one the page made for you, keep with Copy or the download.
  - From then on that browser syncs by itself: its saves go to the server after the game saves and when it closes,
    and a newer save from your other browser comes in when the page opens and when you press Play. If both browsers
    changed them since they last synced, the page asks which to keep: it shows both, their profiles, money and when
    they were saved, marks the newer one, and asks again before either replaces the other. Nothing syncs until you
    pick, so Play asks first. A send the server kept without the page hearing back (a timeout, a frozen tab) is no
    conflict: the page knows it as its own. Before the cloud's saves replace the ones in this browser (Use the cloud's,
    Load, Go back), the page keeps a copy of yours here for 30 days, and Put back brings it back (swapping again is
    possible). A browser with no profiles never sends its
    empty saves by itself: it offers the cloud's instead (keeping the empty ones asks first: every browser on the
    passphrase loses its profiles). The page also asks before cloud saves with no profiles, or older than the ones in
    this browser (a server gone back), replace yours.
  - The profiles and `settings.ini` go. What belongs to the device stays in each browser: F12 screenshots, DVD and
    magazine covers (a cover is a picture of 1 MB: another browser's crib lists it, but the game says it cannot load
    it), the game's graphics options, the record of the LAN games and free-roam races this browser hosted
    (`gamefile.bin`), and of the settings full screen, the resolution scale, render size and pixel limit,
    Upscaled HUD and Detailed Map, the frame rate and its counter, the output latency, the controller's settings and
    how many players' cars free roam shows. A phone keeps its own and a PC its own.
  - The server keeps the copy of an earlier day too: "Go back to ..." brings it back when a day went wrong.
  - Your passphrase can also claim your name (**Online, Your name**: no one else plays under it; see "Your name is
    yours" under Online), so in another browser your name comes back with your saves.
  - Stop syncing leaves the saves where they are, and the passphrase in the box (your claimed name stays the
    passphrase's: without it, this browser plays it with digits); Delete from cloud deletes them on the server (your
    browsers keep theirs), and frees the name it claimed for anyone to claim. A passphrase nobody used for two years is
    deleted from the server. A browser
    whose passphrase the server no longer has keeps it and sends nothing; Sync now looks again and offers to send its
    saves there.
- **Autosave:** the game saves your progress by itself after races, purchases and changed options. The game starts
  every profile on Save = Prompt, whose "save?" question opens on No, so Enter through the results skips the save;
  the page sets each profile to Autosave once (the game's Options, Gameplay, Save), at the first Play after the
  profile was saved. Pick Prompt or Off there and it stays. Game, Autosave off leaves the game's own setting
  alone.
- **When it saved:** "Progress saved" shows over the game each time it saves your profile, F9 shows the last save, and
  after the game closes the start page says when it last saved (or that nothing was saved during that game).
- **Rename:** Rename next to a profile in Saves gives it another name: letters and digits, up to 7, as the game's
  own name field takes them. Its career, cars and DVD and magazine covers go with it. Quit the game first. When
  "Your name" is empty, the other players see the new name.
- **Screenshots:** F12 while playing saves the picture as a PNG beside your saves. Saves on the start page shows
  them, newest first; click one to see it large, page through with the arrow keys, download or delete it. **Delete
  all** beside the heading deletes every one, after a question that says how many and how much (a backup with many
  screenshots can be too large for the browser to download). Downloaded backups keep theirs.
- **Play time:** Saves shows how long you have played in this browser, and the start page under Play how long the
  last game was. Only play counts (the game in sight, some input in the last 5 minutes), in this browser only (not
  synced; a private window counts nothing). Counting began on 26 October 2026 and stopped at about 2 hours until
  31 October, so a browser that played before the page showed the time says "at least".
- **Backup:** Saves, Download backup gives one zip with your profiles, the game's options (`registry.txt`),
  `settings.ini` and F12 screenshots.
- **Restore:** Saves, Restore puts a zip back, on this PC or on another one. It replaces what this browser
  has, after showing what is in the zip, including what its `settings.ini` would change on the network (free roam
  on, the name others see). A very large backup keeps every save and settings file. Only screenshots past 512 MB
  are left out. Restore only backups you made yourself or trust.
- **Profiles from the PC game:** Restore takes them too. Zip the folder `%LOCALAPPDATA%\NFS Underground 2`
  (type that in Explorer's address bar), or pick one profile's own file in it (`<NAME>\<NAME>`, no extension). They
  are added beside the profiles in this browser, with their DVD and magazine covers; one of the same name is
  replaced, after asking. A profile saved by another version is left out, as the game would not load it. One
  changed by a save editor is restored with a warning: a value the game would not make itself may crash it or break
  the career. One with cars a mod added is restored with a warning too: this game does not have those cars, so each
  one shows here as a stock car (a Peugeot 206 with stock parts), and the save keeps the car as it is, for the modded
  game, unless you change it here (parts, tuning, a trade). A profile folder's GARAGE.DAT and MODPARTS.DAT (slots 6-10,
  the parts this game keeps beside a profile) come along from a zip of the folder.
- **Backups are your safety net.** When the disk is nearly full, the browser may clear a site's storage unless it
  promised to keep it. Chrome decides that by itself, and the page cannot see how full the disk is, so it does not warn.
  Firefox asks by the address bar (the Saves section says so while it asks): allow it. Make a backup now and then,
  or use cloud saves.
- **Preloading the game data:** "Preload the game data" in Game data on this device fetches the game folder but the
  movies into this browser, compressed on the way, with its progress and the time left. You can play meanwhile:
  preloading pauses while the game runs and goes on when it ends. Stop it whenever you like; what came is kept, and
  "Preload the rest" goes on from there, also after a reload. It needs about 2 GB of free disk space. The page says
  so before it starts when the browser has less room.
- **Game data on this device:** "Delete game data" frees the space it takes on this device. Your saves stay; the game
  loads the data from the server again when it needs it.

## 6. Free roam with other players

Free roam is shared with **everyone** on the server who turns it on. Join a Crew to find your friends among them,
or use a Room to keep to a group.

1. **Online, Free roam with others** on the start page is on by default (off: your career's free roam alone).
   **Online, Your name** is the name the others see (empty: your profile name). **Online, Your flag** puts a flag before it (a country, England, Scotland, Wales, Northern
   Ireland or Quebec; none at first). Typed before you have a profile, it is also what the game's name box for your first profile
   starts with, instead of `NAME` (its letters and digits, 7 at most; Enter takes it).
2. Everyone plays from the same server's address.
3. Each player starts or loads a career and drives in free roam. Players find each other by themselves, and their
   cars appear in your city with their names over them, as in the game's own LAN races.

Good to know:

- **How many:** up to 24000 players on a server set up with `web/deploy/` (2000 with the older Node server), 128 on
  one started by hand (its owner can change that). Only free roam and the LAN and Online screens take a place;
  single-player takes none. When it is full, you wait in line for a place, first come first served: the top of the
  screen shows your place and, once a few went in, about how long it takes. You play alone meanwhile and join the
  others by yourself when it is your turn. The page menu's "Stop waiting: play offline" leaves the line for the rest
  of that game, and when the server is full as you press Play the start page asks whether to wait in line or play
  offline (or, the first time, says so in its free-roam question). The server pairs each player with the players
  nearest to them, as many as their game shows cars (fewer while it is busy, 8 at the least): 32 on computers, 24 on
  tablets and 16 on phones, or what you pick (Online: Players' cars shown: 16, 24, 32, 48 or 64; more cars can lower
  the frame rate). You get the cars of your nearest players even where they show fewer than you: their game sends
  you their car without showing yours, and their car lets yours through (no outrun or race invite between the two).
  Standing or rolling slowly (a car meet), you get the cars within 60 m first, and one that came that near stays at
  least 30 s; driving faster, the ones ahead of you first. Their names show
  over the cars within 100 m, and each gets an arrow on the minimap when it is near and a marker on the world map (M),
  in the game's orange. The game's own outrun challengers are grey on both (the legend's Opponent Car too), so you can
  tell them from players. The minimap also has an arrow, the same as a car's, for the players near you whose cars
  your game does not show (the nearest 64 within its reach, from the server four times a second), so a crowd looks
  as big as it is; theirs are left out at the minimap's edge, where the cars' arrows point the way. The world map
  also marks the other players in free roam, the nearest 4096 past those (2048 on phones)
  32, and while it is open every marker moves smoothly with its player. Its legend (the list on the
  map's left) has three rows of ours after the game's: **Players**, **Players' races** and **Car meets**. Pick one with
  Up or Down and Enter crosses it out, as with the game's own rows: the map then leaves out the other players' markers
  (a crew-mate's stays), the players' race lobbies (yours stays) or the meets until you tick it again, and the game
  remembers it. A spot where 20 or more players have been parked for a minute is a car meet: a green star and "Meet:"
  with its number of cars on the world map (the new career's start doesn't count). Picking the Car meets row picks
  the nearest meet, Left or Right the next, and C starts the GPS there; it stops when you arrive. A player in a
  race, a shop or the menus is not in your free roam: no car, no arrow, no marker until they are back. A player farther than 300 m
  sends you their car 5 times a second instead of 20 (past 1 km, twice), which saves traffic and doesn't show at that
  distance. When many players arrive at once, their cars load one after another, about one a second, so the last of 32
  can take half a minute to appear.
- **Ghost mode:** Online, Ghost mode. **Off** (the default): you collide with the other players' cars. **Players**: you
  drive through them, and they through yours. **Everything**: traffic and the game's tuners pass through you as well
  (and through the other players' cars on your screen), in free roam with others only: races stay as the game has
  them, and the tuner you race in an outrun is solid while it runs, as in the game. An outrun with another player is
  solid only when you both have Ghost mode Off; with Players or Everything you two drive through each other.
  Traffic and tuners are in your game only, so this changes nothing for the others. The page menu (F9) switches
  between the three while you play, at once, and keeps it for your next games. In **World 4** Ghost mode is Off for
  everyone: the page holds it there (the menu's Ghost mode says it stays off), and yours comes back when you leave. With Off, a car that appears on top
  of yours, at a garage or after a jump, lets you through until you are apart. Each
  player's own game moves their car: a car you hit is pushed in its owner's game, and moves on your screen as it does
  there. A hit is shared between the two cars by their models' weight (0.96 t for the Peugeot 106 to 2.9 t for the
  Hummer): driving into a standing car of your weight, you go on at about half your speed and it leaves at about the
  other half, where you used to stop dead and it flew off faster than you came; driving the light Peugeot 106 into a
  standing Hummer, the Hummer leaves at about a third of your speed. Such a hit starts the game's slow-motion crash
  view only when it is hard: from about 155 km/h of closing speed between two cars of the same weight. You also drive
  through a car whose player is paused (or you are), one that has stood still for a minute (or yours has), and any car
  within 20 m of a shop's, the garage's or the car lot's door, so a crowd can't wall off an entrance. A car that has
  stayed within 6 m of one spot for 20 s, after at least four hits from at least two other players' cars in the last
  minute, is in the way: everyone drives through it until it leaves that spot, so nobody can park across a road (the
  airport's way out) for long. The same goes for the start of an event that is open in your career (a race, or one of
  the stage's other events): within 20 m of it you drive through every car, and every car through yours, so nobody
  blocks it; for players who don't have that event it is an ordinary spot. A player on an older version doesn't know
  about your events or your Ghost mode setting, and collides with you there as before.
- **Ghost mode hint:** a new career starts in the airport's car park, and every new player drives out of it into the
  others. As your car leaves that spot with Ghost mode off (while other players are in free roam), a note at the top
  says to turn on Ghost mode in the menu (F9; ☰ on a touch screen, Home on a controller), for 15 s (not in World 4).
- **Names over the cars** follow the game's own player-names option, as in its LAN races: Show Player Names in the
  game's Options, Gameplay (also the pause menu's) turns them off. A player who paused shows as "paused" there.
- **Horn:** hold N to honk, or click the controller's left stick (on a car with hydraulics that click works the
  hydraulics: honk with N). The others hear it from your car: louder the nearer they are, from the side your car is on, and lower in pitch as you drive away from them. Pick yours in
  Online, Your horn (the play button next to it lets you hear each one): dual tone, single tone, air horn, train horn,
  Klaxon, La Cucaracha (it plays while you hold it), clown horn, sad trombone, Dixie horn, old car horn, broken horn,
  sputtering horn, or the horn of the film The Car (1977), short or held. Each sounds only while you hold it. The others
  hear the one you picked; players on an older version hear the dual tone.
  Each player's horn is also pitched a little differently by their name, so two players with the same horn sound
  apart. It sounds while the game runs, not in the pause menu or on the map. It works in Online and LAN races too.
  How loud the horns are (yours and the others'): the game's Options, Audio, Horn Volume, also in the pause menu's
  Options, from 10 % to 100 % (the most, and the default), times the game's Master Volume, as for the game's own
  sounds (none with Master Volume at 0). Moving it sounds your horn at the new volume.
- **Quick chat:** say one of your sixteen set phrases to the players near you. There is no typing, so there is nothing
  to read that someone made up, and everyone reads a phrase in their own language. Press 1 to 4 for a group, then 1 to
  4 for its phrase; on a controller, press the right stick in, flick it (up, right, down, left) for a group, then
  again for the phrase; on a touch screen, the chat button shows all sixteen. Esc closes it (on a controller, a
  second click). These are the sixteen you start with:

  | 1 Hi | 2 Reply | 3 Drive | 4 Race |
  |---|---|---|---|
  | Hey! | Yes | Follow me! | Race? |
  | Nice car! | No | Wait up! | Join my race! |
  | Thanks! | Sorry! | Let's go! | gg |
  | Bye! | lol | Nice! | Countdown (special) |

  Online, Your phrases, Choose phrases puts any of about 160 phrases in each place (greetings, replies,
  thanks and sorry, compliments, driving together, car meets, races, reactions, help, film quotes) and names each
  group. The film quotes stay in English in every language.

  **Countdown** is a special phrase, with a stopwatch in the picker (in Choose phrases under Special; in the sixteen
  you start with in One more?'s place, since 2026-11-03): a start for the players lined up behind you in free roam.
  It counts 5, 4, 3, 2, 1 and GO!, big in the middle of the picture for you and the players within 50 m of you, over
  your car for the others who see your phrases. While one is on near you, and for 10 seconds after its GO!, nobody
  else's shows and yours waits. In a race it is dimmed and does nothing (the race has its own start).

  A phrase shows over your car and in the chat log on the left, for the players within 250 m (where they hear your
  horn) and everyone in your race lobby, wherever they are; in the lobby's card it shows beside your name. Over a car
  only while its name shows (within 100 m, in front of you, the game's player-names option on). Three phrases in six
  seconds at most; then the picker asks you to wait. Online, Quick chat turns it off: you then neither see
  nor send phrases, and the others' games send you none. Players on an older version neither see yours nor send any,
  and those who have not reloaded the page since the phrases came see only the first sixteen (since the countdown
  came: no countdown).

  It works in races with other players too: the races of free roam's lobbies, the game's Online races and its LAN
  races, with free roam on or off, while you drive and on the results (free roam's trips leave those after about
  10 seconds; an Online race goes back to the game room, which has its own chat). Same keys, stick and chat button,
  never in a race of your career or a Quick Race. A phrase goes to everyone in the race and shows in the chat log on
  the left, not over the cars; the race's creator passes each player's on to the others, so with a creator on an older
  version you hear only the creator's. Players you block (Online, More online settings, Blocked players) are not
  shown. With Quick chat off you neither see nor send phrases in races either.
- **Engines:** the others hear your engine from your car, as you hear it yourself: the game's own recordings of your
  car's engine (each car has its own, and the engine upgrades change it), pulling as you accelerate and letting off as
  you lift, at your revs, with the limiter and a launch's wheelspin as your game plays them; louder the nearer they
  are, from the side your car is on, duller far away and lower as you drive away. Every player's car sounds, however
  many there are: the game itself gives an engine only to a few cars, so before, the first three players near you
  sounded like one of its AI racers and the others not at all. A player on an older version sends no engine: their
  car sounds from its revs and throttle, as well as those tell; their game still has the old engine sounds.
- **Hydraulics and nitrous:** the others see your car lift, tilt and bounce on its hydraulics, with its wheels on the
  road, and your nitrous as the game draws it on any car: the light trails behind it. They hear them from your car
  with the game's own sounds, as you hear your own: the nitrous going on and off, letting it out while standing or
  off the throttle, each wheel's pump and valve and a landing, louder the nearer they are. A player on an older
  version sees the body move but not the wheels, and no nitrous, and hears none of it.
- **Tyre smoke:** when you slide, spin your wheels or do a burnout, the others see the smoke from your tyres, as the
  game draws it for any car. Between players on different versions, neither sees the other's.
- **Hood, trunk and doors:** parked in free roam, O opens the hood, pressed again the trunk instead, then both doors
  instead, then all of them, then closes them all; on a controller, hold D-pad down for a second (a short press is still
  Career Status). The others see them open; they close by themselves when the car drives off. The open trunk shows its
  trunk audio, the layout, speakers and amps, on your car and on the others'. Players on an older version see your car
  closed.
- **Headlights:** the other players' headlights light the road in front of their cars, as yours do, a little dimmer
  and in their own colour; in Online and LAN races too. Display, more: Other cars' headlights (All cars: AI racers and
  traffic too; Off: only yours, as in the original game). The Windows plugin draws only your own.
- **Outruns:** stay within about 25 m of another player for 4 seconds, away from the shops' and the garage's doors and
  from either player's open events (20 m), and not in a crowd (4 or more other players within 25 m of you, as at a car
  meet), and the game offers an outrun, as it does with its own tuners: the outrun icon lights up and the top of the
  screen says "Press Enter to challenge ... to an outrun" (on a controller, D-pad up, the game's Engage). The other
  player sees "... challenges you to an outrun" and takes it with Enter as well, or lets it go: a challenge lapses
  after 15 seconds, or when you are more than 60 m apart. Then both games run the game's own outrun against each
  other's car: its "Feet" meter, and whoever gets 1,000 feet (300 m) ahead of the other wins, and the bank pays or
  charges as in an outrun against a tuner. Leaving it (back to the menus, quitting, losing the connection) loses it.
  The other players' cars stay, and they see the two drive. Players on the Windows plugin are not offered outruns.
- **Drift battles:** with drift mode on (X), the challenge offered as for an outrun is a drift battle instead: "Press
  Enter to challenge ... to a drift battle" (X off first for an outrun). The other player takes it with Enter (their
  drift mode comes on for it, and goes back off after if it was off). After a 3-second countdown each of you has 90
  seconds to bank as many drift points as you can, anywhere in the city: the multiplier starts at X1, there is no
  nitrous (as in the drift races; yours is back after), X does nothing, and the two cars, and every other player's,
  drive through each other, so nobody can wreck your drift. A scoreboard under the drift panel on the right shows the
  time left and both players' points, the more first (the other's as their drifts bank); a drift still counting at
  the end counts as it stands. More points win:
  the winner gets $100 out of the loser's bank (never more than the loser has; not in Quick Race's Free Run), a draw
  pays nothing. Leaving it (back to the menus, into a race or a shop, losing the connection) loses it, and then no
  money moves. Players on an older version (and the Windows plugin) get an outrun's challenge instead.
- **The game's own tuners** come out to challenge you in free roam with other players around, as they do offline, so
  their outruns and what winning them opens up (the unique parts) are there online too. The other players' cars stay
  while you race a tuner; they see your car, not the tuner, which is in your game only. Both are offered: a tuner
  within 30 m of you (the game's own reach for its challenge) comes first, and no outrun with another player is
  offered or taken until it is farther off; while another player's outrun is offered, the tuners keep driving but
  none challenges you. Within 20 m of a shop's or the garage's door, or of an event, Enter is for the door: no tuner
  challenges you there, and a challenge already on the screen goes when you get there. No tuner comes during an outrun with another player (from the challenge on) or while you are
  in or by a race lobby. On the Windows plugin the tuners stay away while other players are about.
- **Races with other players:** a race of your career can be raced with the players around you, as the game's own LAN
  race on its track, in your career car. That takes a car of your own: in a new career's prologue (the 350Z you
  start in) you cannot join or open a lobby, and the panel says so; from your first car on you can. Lobbies are
  joined from your career's free roam only: in Quick Race's Free Run the panel says so too.
  - **An open race** (its marker in the street): its card asks Accept or Decline as always, and Accept asks once more:
    **Multiplayer** or **Solo** (the career race, as before). Solo has the focus, so Enter at once races it Solo as
    the game always did; but with another player's lobby waiting there that you can join, the panel shows it (E for
    the next one, as below), the question names its host and **Join** has the focus. A win counts in your career
    either way (below).
  - **A race that is not open** in your career has no marker of the game's. Within about 50 m its start shows
    "Circuit (multiplayer)" or the like, and at the start a panel on the right (under Bank) says it is multiplayer
    only there and why (you won it in your career, your sponsor's contract has no place for it, a URL race before
    its wins, an SUV race without an SUV), or, for a race of your stage the game has not opened yet, "★ A win counts
    in your career" (its words end in "- career"), and that Enter opens a lobby. A spot offers the race of your
    stage there, else the last one you won there: never one of a stage you have not reached. None in the prologue,
    none while a story task runs, and none where the game has something of its own to enter at the same place (a race
    open in your career there, a cover shoot): Enter is the game's there, and an open race's card asks Solo or
    Multiplayer as above.
  - **Multiplayer opens a lobby** at the start. Its panel has four parts, a line between them: the race ("Sprint",
    "Lobby 3/6"), its stage, track and laps, and ★ when a win counts in your career; its players, the host first
    and marked, ★ beside each player a win counts for, friends and crew-mates in lime, you in bold, then its open
    places (6; drag 4, 3 on the three-lane track), and under them a small speedometer: the fastest other car against
    yours with the engines evened out, counting most of what the race does (the engine is not all of a car: a car
    rated 1.35 times yours shows as 1.07 times, 1.8 times as 1.15; straight up: as fast as yours; in the red from 1.25
    times, from about 2.5 times rated, a stock car against a maxed one; Street X and drift races, not evened out, as
    rated); the host's settings (who can join, invite friends); then this lobby or the next (the keys,
    what is going on, how to leave). The players near see "Ann's circuit (1/6)" over the start (from about 250 m;
    several lobbies at one start stack there, a line each, the fuller first, at most four and then "+2 more");
    everyone in free roam sees its race's icon on the world map (M), and the nearest four lobbies their words beside it
    ("Circuit 1/6") where these cover no other icon (the legend's Players' races row hides them). They join at the
    start: within 15 m of it the panel shows the lobby and Enter joins (at an open race: its card's Accept, then
    **Join**).
    **Several lobbies at one start:** the panel shows one at a time, **E** (or a click or tap on "Lobby 2 of 3") the
    next, and **B** ("New lobby") opens one of your own beside them, from any of them. It starts on the lobby Enter
    would pick for you: one a friend or crew-mate of yours is in first, then a race that counts in your career, then
    one on your side of the race's stage (its host past that stage if you are, or not if you are not), then the one
    whose cars are nearest yours, then the fullest. Up to 6 players. A lobby you can't join is not shown to you
    anywhere (at the start, over it, on the world map): a full one, one on its way to the race, one that keeps you
    out (below); Enter there opens a lobby of your own. Drive more than 40 m from the start to leave a lobby; the host leaving calls it off, and a lobby nobody joins closes after 5 minutes. A host who seems
    away (none of the game's keys or controller buttons and no driving for 2 minutes while others wait) gets a
    30-second countdown on every panel of the lobby, then it closes; one of those keys keeps it. A lobby is within
    your world, as everything in free roam. At a race's start Enter is for the race: no outrun is offered there.
  - **On a controller** the panel shows the D-pad in place of the keys: up (the game's Engage) joins, starts the race
    or opens a lobby; left held a second opens a new lobby beside the others, goes round who can join (the host) or
    leaves a lobby joined from afar; right held is the next lobby. A short press of left or right stays the game's
    (World Map, SMS), as with D-pad down's hold; a direction you put another of the game's controls on stays the
    game's. Invites are in the menu's Friends.
  - **Who can join:** the host's **V** (or a click or tap on its line in the panel) goes round its choices while the
    lobby waits. **Stage 2 and below can join** (the host's own stage; the default) keeps out players past it, but
    the host's friends and crew-mates. **Friends & crew can join:** only the host's friends and crew-mates see it,
    at the start, over it and on the world map, and only they can join; the players already in it stay. **Everyone
    can join.** A
    lobby whose race counts in its host's career has no Everyone.
  - **Inviting friends:** the host's **Z** (or "Invite friends" in the panel) opens the menu's Friends, where each
    friend in free roam in your world has an Invite (a flag) while your lobby has room. The friend gets a line over
    the game, "Ann invites you to a circuit (2/6)", for 20 seconds; their **Z**, a click or a tap joins from wherever
    they are, without driving to the start (a lobby they were in is left for it). Their race leaves from where they
    are and brings them back there; driving away does not take them out, their **Z** ("Leave" in the panel) does.
    Crew-mates who are not friends cannot be invited: the server does not know crews by name. E, V and Z can be set
    on the start page (Controls, Site); a key of the game's own controls stays the game's.
  - **The host presses Enter** to start once another player is in. Every panel of the lobby says "Starting the race…"
    for 2 seconds, then every game in the lobby goes to the race by itself, behind a screen with the lobby on it and
    where the trip is ("Loading the race"). The race's LAN server starts in the host's game as soon as a player joins,
    so by the Enter it already takes the others, who connect to it the moment they reach the LAN menus. Out
    of free roam and through the LAN menus (your keys and controller do nothing meanwhile) to the race on the career
    race's track, direction and laps (a LAN race takes at least 2 laps, Street X 4), with no traffic and no AI
    racers. You drive the race. After the results every game goes back by itself, behind the same screen, through the
    main menu and your crib, to where it left free roam, and the panel says your place and prize: about a minute for
    the way out and back.
  - **A URL event of 2 or 3 heats** races them all in one trip (the lobby says "2 heats"): after each heat's results
    every game goes on to the next heat's track, with the standings between the heats on the screen, about 10 seconds
    each. Each heat scores as in the career (8, 6, 4, 3, 2, 1 points by place, none without a finish); most points
    wins the event, a tie goes to the better place in the last heat. Your place in the event is what counts for the
    career and the prize. Leaving between heats leaves the event; a heat that ends early ends it unfinished.
  - **The cars are evened out** in circuit, sprint, drag and URL races: at the start every game rates the race's cars
    as the game itself does (its performance rating: the engine, gears, weight and drag with every part in) and
    changes each car's engine power so the cars come close: they head for a rating between their middle and the best
    (two cars: two thirds of the way up from the slower one), and each goes nine tenths of its way there, so the
    better car keeps a small edge (of two cars, one rated a third higher, about 3 % is left). In a drag race, where
    even that edge decided most races, each goes all of its way there. The power changes by at most half again as much
    or a quarter less (the nitrous with it). No car keeps a stock car's top-speed governor (as with an ECU part), so
    the extra power counts at speed too. Grip, brakes, gears, weight and your tuning stay as they are, so your car
    still drives as itself and your upgrades still count, by less; a car far ahead of the others stays ahead, by less.
    The lobby says so before you join ("Engine power is evened out", left out where it warns you, below), and after
    the race the note says how your engine was changed. Street X and
    drift races leave the cars as they are: there the rating did not decide who won.
  - **A lobby warns you** when its race's stage usually has much faster cars than yours ("Stage 5 race: the cars here
    are usually much faster than yours"): a stock car (the game's lowest class) at a stage 3, 4 or 5
    race, a class-2 car at a stage-5 race. In the live races of 2026-10-31 to 11-03 such cars won a quarter to half as
    often as an even field would let them, evened out or not. You can still join.
  - **A win counts in your career** where you could win the race with Solo: a race open in your career (its marker in
    the street), or a normal race of your stage you have not won yet (the game opens only a few of a stage's races at a
    time; a multiplayer win takes any of them). A sponsor or URL race counts only when it is open, an SUV race only in
    an SUV; never a race of a later stage, a story race or one you have won. Win it and your career gets the game's own
    win, as Solo gives it: the race is won, the career's prize for it goes into your bank (or your place's prize money
    below, where that is more: $400 for 1st at stages 1 to 3, never less for a race that counts), and the stage's wins and
    story go on from there; a stage's final race moves your career to the next stage, and its movie plays after the
    crib's save, before free roam (a key skips it, as in the game). A win the way back could not give in the crib (the
    trip lost its way) waits for your next crib visit, kept beside your profile, so it is still there after a reload.
    Where the game would offer you its sponsors, your
    crib on the way back asks with the game's own dialog, one offer after the other ("Sponsor offer 1 of 3: ...
    Signing bonus ..., its races pay ... Sign with them?", **Yes** signs, **No** shows the next offer), and your keys, controller and taps are yours
    until you sign. A **friend's or crew-mate's win** (a player on your Friends list, or in one of your crews) counts
    for you too, when you finish the race; any other place than 1st leaves the race to win ("Only a win counts in your
    career", after the race). The panel marks each player the race counts for with ★ ("A win counts in your career"), and the
    words over such a lobby or spot and beside its world-map icon end in "- career". A lobby whose race counts for the
    player who opened it always takes players up to that race's stage and the opener's friends and crew-mates (any
    other lobby does unless its host picks Everyone): a car of a later stage would win it most of the time, however
    the cars are evened out. Past that stage you don't see such a lobby (at the
    start, over it, on the world map), and Enter opens a lobby of your own beside it. Solo stays as it always was.
  - **Any other race** pays only prize money: 1st gets what a normal race of your stage pays (stages 1 to 3 $400,
    stage 4 $1,200, stage 5 $2,000), 2nd to 4th three quarters, half and a quarter of that (never less than $300, $200
    and $100), 5th and 6th nothing. **Quitting the race**
    (its pause menu's Quit) costs 3/16 of what 1st pays you ($75 at stages 1 to 3, $225 at stage 4, $375 at stage 5;
    never more than your bank holds), as the panel says before you join: the host's quit ends the race for everyone,
    and in a race of two either player's does. When everyone else quits a race that way, the one who stayed wins it
    (1st: the career's win where it counts, else 1st's prize; a URL event's remaining heats too); a race that ends
    under you any other way (a lost connection, a game closed) costs nothing and counts for nobody. The win, the prize or the fee
    goes in at the crib on the way back, and the crib's autosave saves it with your profile (with the game's Save
    option at Prompt or Off it waits for your next save, as any change in the crib does).
  - A player who leaves the lobby in the countdown, quits the game, or whose game cannot set off, or gives up on the
    way, is not waited for (its game tells the host's); the host's game waits 30 seconds at most for the others in the
    LAN race's room, then starts with those who are ready. A race that cannot come together (the host's game gone or
    given up, nobody else in the game in time) ends the trip at once: every game goes back to free roam by itself and
    says why. Players on an older version or the Windows plugin see no lobbies.
- **Crews:** friends who type the same crew name (Friends & crews, Crews, or the page menu (F9) while you play)
  always see each other, however far apart and however busy the server: the server pairs crew-mates first, before the
  nearest players (up to 16 crew-mates each, 8 while the server is busy), and your game gives their cars a place
  first. Their names show over their cars at any distance, with the distance past 100 m ("Sam (1.2 km)"), in front of
  other names, and their minimap arrows and world-map markers (with their names beside them) are in the crew's colour.
  You can be in up to 4 crews; each has its own colour (cyan, magenta, violet, red unless you tap its dot to pick
  another), and the crew list shows how many of each are in free roam now (in the page menu, you count too once you
  drive). A crew of more than 64 players in one world is too big to pair first: they see each other only nearby, and
  the list says so (pick a less common name). Capitals and spaces don't count ("Blue Room" is "blueroom"); a name that
  reads as a slur is no crew. Everyone else is still there, unlike a world. Not private: anyone who types the same name
  joins, but other players never learn your crews: the server tells each game which players near it share one. A
  player on an older version is in no crew. A few seconds after you start driving in free roam, the
  log on the left has a line for each of your crews with others in free roam ("Night Owls 3 in free roam", in the
  crew's colour; you count too).
- **Inviting a friend to a crew:** a friend who is in free roam now has a crew icon (two people) on their line, on the
  start page (Friends & crews) and in the page menu's Friends, while you are in a crew: with one crew it invites them
  to it, with more your crews open under the line and you pick one; a toast at the icon says it was sent, or why not
  (not in free roam now). The friend gets a note at the top, with a lime border, "Ann invites you to crew "Night
  Owls"": the race invite's key (**Z**, set on the start page under Controls, Site), a click or a tap joins the crew
  and your world (crew-mates meet only in one world; your settings keep both, as an invite link's Join does). Under a
  race invite when both show, Z takes the race. Not taken within 20 seconds, it waits in the page menu's Crews (✓
  joins, ✕ declines) until that game ends; with 4 crews already, Join says so and it waits there beside your crews'
  Leave. Only the friend and the server see the crew's name, and the server keeps
  it nowhere and never logs it; six invites at once, then one every 5 seconds (race and crew invites together).
- **Friends:** touch front bumpers with another player (nose to nose, both cars' fronts) for 3 seconds, solid or in
  ghost mode, and a note at the top, with a lime border, offers **Add Bo as a friend**: press **F**, click or tap the
  line, or use the page menu (F9, ☰, or Home on a controller). The other player's line then says **Al wants to be
  friends: accept**; once both said yes you are friends. Touching the side or the back of a car offers nothing, nor
  does a race, an outrun or a race lobby. Both of you need a claimed name ("Your name": a claim needs cloud saves);
  without one the line says so. Your friends are listed in the start page's **Friends & crews** tab, one line
  each: where each one plays now after the name (free roam and its world, the game's Online lobby, offline),
  with a Join arrow to drive in their world, Discord's mark when they gave their Discord username (a click copies it,
  for Discord's Add Friend), an envelope for your messages (lime with a dot while some are unread) and a grey bin to
  remove them; a request you did not answer in the game waits there (30 days), with ✓ and ✕, and one
  you sent has a ✕ to take it back; a lime dot on the tab says requests or unread messages wait. Under the list,
  **Add a player** sends a request to a player who is not near you: type their name (a claimed one) and press
  Enter or +. If they are driving in free roam, their line says **Al wants to be friends: accept** for 15 seconds
  (**F**, a click or a tap, or the page menu, accepts); a request that waited shows there at the next game's start.
  **Your Discord**, under it, is your Discord username for your friends (and nobody else) to add you on Discord: only
  a username as Discord has them fits (2 to 32 small letters, digits, _ or .), and an empty field takes it away.
  In free roam the server pairs friends first, as crew-mates, so you see each other however busy it is: a friend's
  name over the car shows at any distance, in a pale lime white (a friend in one of your crews has the crew's colour),
  and so do their arrows on the minimap and the world map. When a friend comes into free roam, the notices on the left
  say so (with **I Message** under it when they are in your world). The page menu has **Friends** in every game in
  free roam with other players: the requests to answer (✓ and ✕), who is in free roam (and on which race track, if
  one: Tracks below), with **Join** to go to them (their world, their track, then a short loading screen and your
  car stands on the road behind theirs; in the city only where your career has opened the city: a friend behind your
  career's walls is out of reach, and the line says so) and Discord's mark to copy one's Discord username, the
  others in a line, and **Add a player**;
  with no friends yet, it says how to add one. A friend is a
  friend in the game's Online mode too (EA Messenger), up to 250. In free roam the server takes a request only between
  two players whose cars are within 30 m of each other; by name, from the start page or the page menu, five at once and then one every
  30 seconds (a player you block in EA Messenger never sends you one again). Your friends see the name of
  the world you play in, nobody else (it is told to the server only once you have a friend, and kept in memory only).
- **Messages to friends:** a friend's message shows in the log on the left, where quick chat's phrases show, with an
  envelope, and **I Write back** under it. In free roam press **I**: a card in quick chat's place answers the newest
  message, or, with none to answer, lists your friends (where each one plays) for **1** to **9** to pick one. Type
  (120 characters at most), **Enter** sends, **Esc** closes; the game gets no keys while the card is open. Your own
  message shows in the log as "To Bo ...". On a touch screen tap a message to answer it, or the chat button's
  **Message a friend**. On the start page, the envelope on a friend in the Friends tab opens your conversation, lime
  with a dot while there are messages you have not read. A message reaches your friend at once wherever their page is
  open (in the game's Online mode, in EA Messenger); a friend who is away gets it when they are back (it waits 7
  days), and your log says "(gets it when back)". A message that came while you were in a race, a shop or a menu
  shows once you drive in free roam again. Only friends can message each other; a message with a slur in it reaches
  no one (three in ten minutes turn your messages off for ten minutes), and Remove or Block stops a friend's. The
  server keeps a message only until it is delivered; your conversations are kept in your browser (the last 40 with
  each friend).
- **Worlds:** free roam is split into worlds, and you see only the players in yours. **Main world** is everyone's
  (the default, and the busiest); **World 1** to **World 4** are for anyone who wants a quieter free roam, and
  **World 4** has Ghost mode off for everyone in it; **Own name…** makes a world of a name you type, shared by
  whoever types the same (capitals and spaces don't count). Pick one in the page menu (F9, **World**: every world
  with how many are in free roam there, on its race tracks too, yours checked; a tap switches at once, back to the game, and your settings
  keep it), or on the start page (Online, **World**, the counts in its list). Arriving, the log on the left says the
  world and how many are there. Friends and crew-mates meet only within one world (the menu's Friends has Join, which
  takes you to them), and so do race lobbies. An invite link (`#room=`) joins a world too. A page from before
  7 November has a **Room** name box under Online instead (the same thing: empty is the main world): reload it. A world is a filter between players, not privacy: every browser on the server still sees your name ("Your
  name", or the profile name), whether you are in the menus or driving, and the world, and someone with their own
  tools could join it. Play on a server only with
  people you would show your name and car to.
- **Tracks:** the career's race tracks are places of their own beside the city, and free roam can go there: the
  page menu (F9, **Tracks**) lists them by the career's names: the URL's Airport Circuit and Bayview Speedway, the
  Stadium's and the Parkade's drift, the Bayview Bridge, Central Station and South Runway drags, and Street X's
  Industrial Park and Parkade, each with how many players are there. Pick one: after a short loading screen your car stands on a race's start line there, with the players of your
  world who went to the same one (each is a place of its own: you meet nobody from the city there, and the city's
  players don't see you). **Back to the city**, at the top of the same list, takes you back to where you left. A track
  has no traffic, events, shops or World Map; Respawn and outruns with other players work as in the city. A trip goes only while you drive in your
  career's free roam: not in a new career's prologue (your own car first), not during an outrun, a race or a race
  lobby, a timed career task or with two players on one screen, and not while you stand on an event's or a shop's
  marker; the list says why when it can't. A save made on a track (the pause menu's Save) keeps the city place you
  left, so your career loads in the city, in the original PC game too, and so does quitting there.
- **Blocking:** Online, More online settings, **Blocked players**: names as they show over cars, separated
  by commas, up to 32 (capitals don't count). You and they never see each other in free roam, wherever you are: no
  car, no name, no horn, no quick chat or outrun, no message about them, nobody on the world map. Neither of you sees
  a race lobby the other hosts or is in, so you don't race each other from free roam (unless you both join one at
  the same moment). In a race you are both in anyway (an Online or LAN race), your page shows none of their quick
  chat phrases. It takes effect the next time you press Play. It goes by name: a player who changes a claimed
  name stays blocked while the old name is still theirs (14 days); after that, or for a name nobody claimed, block
  the new name. The game's Online menu has its own: block a player in EA Messenger there. The server's log says whom
  you block, so its operator sees who many players block (and can ban them). A server of before this version takes
  no notice.
- **Who sees what:** with free roam off (the default), nobody in free roam sees you, and the game joins the server's
  network only in its LAN and Online screens. With it on, everyone on the server sees your name and status, and
  players in free roam with you see your car and where it is. The server reads where your car is, to pick the players
  near you, and keeps nothing of it, unless your car moves as no car of the game can (a jump across the map, a speed
  hack): then its log keeps where the car went from and to, with your name and the names of the players near there,
  for the server's operator. The World Map's jumps and the Respawn button don't count. After a multiplayer race your
  game tells the server your place, your time and your car as the game rates it (its type, power, weight, top speed),
  and the race's results as your game showed them (each racer's time and how far they came). Its log keeps your report
  with your name, for evening out the cars, and names a racer who won by cheating. Nobody sees your real address: the
  server gives each player a virtual one (`10.77.x.x`).
- **A tab in the background** (or another window in front) pauses your game. The others see you as paused: your car
  stays where you stopped, with "paused" after your name. After 8 minutes in the background you stop playing with
  others and your place on the server is freed: your car disappears for them, and your next key, mouse move or button
  brings you back. The same happens after 12 minutes without a key, the mouse or a controller, after a 2-minute "Still
  there?" warning.
- **Closing the tab:** the others see your car disappear after a few seconds.
- **Messages over the game** say when a player joins free roam, is back in free roam after a race, starts a
  multiplayer race nearby, turns free roam off or loses the connection, and, for a player near you, goes into a race
  or quits. The menus and the shops are not announced, and nothing shows while you race.
- **The game's own LAN races** (its LAN menu) work between players on the same server too, with free roam on or off.

## 7. The game's Online mode

The game's own **Online** menu works again, against this server instead of EA's long-gone one: everyone who plays
from the same server address can meet there.

1. Main menu, **Online**. You go straight to the Online Main Menu under your name: **Online, Your name** on the
   start page, or your profile name when that is empty. There are no EA accounts, so the game's EA Login screens are
   skipped.
2. **Lobby** shows the games. **Create Game** (race type, track, options; Game Type Unranked), or **Refresh** and
   **Join Game**. In the game room, chat, press **Ready**; the creator presses **Start Race**. When only some
   players are ready, Start Race counts down 10 seconds: whoever is still not ready then is removed from the game,
   and the race starts without them.

Good to know:

- **Your name** keeps letters, digits, `-` and `_` (3 to 15), online and in free roam alike: `Alex K.` plays as
  `Alex_K`. A changed name applies the next time you press Play.
- **A name that reads as a slur** is not taken: Settings does not save it as **Your name**, the Online mode
  refuses it, and in free roam the other players see `Player` over your car. Digits or signs for letters (`1` for
  `i`), gaps and repeated letters read as the word they spell; a number (a year, two digits at the end) is a number
  (`Hakan1995` and `Dani99` are names). The same goes for Nazi names (and `1488` in a name), hate aimed at a group,
  terror and sexual violence. Swear words are fine.
- **Chat in the Lobby and in a game room** is read the same way, word by word: a line with a slur in it reaches no
  one but you, and after three of them in ten minutes you cannot chat for ten minutes. Swear words are fine. A player
  you block in EA Messenger is not heard there either. In the race itself and on its results, quick chat's set
  phrases work (1 to 4, then 1 to 4; section 6, Quick chat).
- **Submit Complaint** (choose a player in a game room) tells the server's operator about that player, with their
  last few chat lines (of the last ten minutes) that you could see; the operator decides what happens. Without a
  complaint no chat is written down anywhere, only the word that kept a line from the others.
- **Your name is yours once you claim it.** **Online, Your name** says what your name is: free, claimed by you,
  or another player's. **Claim** there claims it with your passphrase (the one of your cloud saves), after a check from
  Cloudflare that a person, not a script, claims it (usually it passes by itself). Without a passphrase, Claim makes
  one and turns cloud saves on, then shows it to keep: it is the only way to play under the name again, in another
  browser or after this browser's data is cleared, and the only way back to your saves. With a passphrase that has
  no name yet, Play claims a free name by itself; Cloudflare's check shows only when it wants a click.
  - One name: once your passphrase holds a name, you always play as it, whatever Your name says. Another name you
    type there is played only after **Change name**, and the line under Your name says which name you play as. With
    the box empty, you play as your claimed name too.
  - While it is yours nobody else plays under it: in the Online menu and in free roam they get your name with four
    digits added (`Alex` becomes `Alex4821`; a name longer than 11 characters loses its end to them), the same
    digits each time for their browser. If someone was online under it before you came, the lobby gives it back to
    you.
  - It stays yours as long as your passphrase does: until you delete your cloud saves, or they go unused for two
    years. In another browser, load your passphrase under Cloud saves and the name is yours there too.
  - One name a passphrase. **Change name** (type another name) changes it once a week; the old name stays yours for
    14 more days, and your friends move to the new one (their lists show it).
  - `NAME`, the game's default profile name, and `Player` can't be claimed: Play asks once for a name of your own,
    and until you pick one you play as `NAME` with your four digits. A name another player claimed: Play asks once
    for another, and you play as it with your digits until then. Neither applies offline or with the network off, nor
    with a claimed name of your own (you play as that one).
  - A name that reads as a slur can't be claimed (the rules below).
  - Without a claim your name is anyone's: whoever is online under it first keeps it (the others get digits), and
    EA Messenger keeps no lists for it: your friends, blocked players and requests last until you leave Online.
- **No name and no profile:** the game's own EA Login screens come instead. **Use Existing EA Account**, any name
  (3 to 15 letters, digits, `-` or `_`) and any password, **Continue**; **No** to "create a profile"; your persona.
  Nothing is checked and nothing is kept: there are no accounts. Type a password you use nowhere else: the game
  sends it to the server only lightly scrambled (the server never reads it).
- **Kept on the server:** only race results per name (Rankings; a name not seen for a year is forgotten), the claimed
  names (each with a code made from its passphrase, never the passphrase, and when it was claimed and last played or
  used: kept as long as the passphrase), and the EA Messenger lists of claimed names, with their passphrase's code: your friends and the
  players you block (names), the friend requests you sent until they are answered (30 days at most), and your
  friends' messages that came while you were away until you are back (7 days at most). Lists of names nobody claimed
  are kept only while their player is online; the lists kept before names could be claimed went to the first
  passphrase that claims each name (the ones of `NAME` and `Player`, which hundreds of players shared, were deleted).
  Of chat, only your last five lines, for ten minutes and in memory, for a complaint. Never your password: the server
  does not read it.
- **Game passwords:** the game asks for the password of a game created with one, and only the same password joins
  it. The server keeps no copy of it, only a check value for that game while it is open, and never shows or logs it.
- **Others see** your name, your game, your chat and your results, never your real address.
- **Every track is open** when you create a game, either direction, whatever your career has unlocked, and a new
  game starts at **2 laps** (the game's own default was 3; Options, Laps changes it). A drift game takes **2 laps** or
  more, as a circuit, ranked too (the game's own least was 4). The same goes for the game's LAN races. The career and
  Quick Race keep their unlocks.
- **Up to 6 players** race in one game (Options, Max Players; the game's own most was 4, and 6 only in URL races).
  Drag keeps one car per lane: 4, or 3 on the track with three lanes.
- **Horn:** N (or the controller's left stick click) honks in a race too, as in free roam: the others hear the horn you
  picked from your car. The same in the game's LAN races.
- **The Lobby lists every open game**, whatever its race type and options (Collision Detection, Race Breaker, Car
  Performance Restrictions, Ranked), those its **Filter** asks for first, until you set the Filter: after Apply
  Filter (or Back) on its screen it lists only the games the Filter asks for. Set the Filter back to its defaults
  (Circuit, no restriction, both options on, Unranked) to see every game again. A game you create or join gives the
  Filter its own settings (the original game does that), and the list is the whole one again until you next set it.
  In the original game the Filter always hid all others, so a game made with Collision Detection off was seen by no
  one. A game with **Private Room** on is not listed, as in the original game.
- **Ranked games** need three players at least. Ranked races give ranking points by place. After a ranked race the
  results screen lists whose results came in (received or waiting), then, once the games of two players sent the
  same finishing order, Official Race Results: each player's place, time (drift: score) and the ranking points the
  race gave (100 for the winner down to 0 for the last; 0 for a player who did not finish, shown as Disconnected:
  who left the race, or was still on the way when it ended, 30 s after the first finisher).
- **A race counts** in Rankings once the games of two players who raced to the end (finished, or were still on the
  way when the race ended) sent the same finishing order (every game sends its own at the results screen), so a race
  counts even when only its winner finished. A player who left the race decides nothing: their game counts every
  player as gone. Each player races from their own browser. **Monthly Point Leaders** (Online Main Menu) shows this
  month's two leaders of each race type and, on its other page, last month's (from 1 December 2026, with November's
  leaders first: the server kept no whole month before it).
- **EA Messenger** (the Online Main Menu's button): Search finds the players online on this server and those with a
  race in Rankings. **Send Friend Request** reaches the other player now, or when they next come online: they see you
  in their list with a green arrow and pick **Answer Friend Request**: Accept, Decline or Block. Your friends stay on
  your list and are told when you come online; **Remove Friend** takes the two of you off each other's lists. A
  message to a friend who is not in Online mode reaches them in free roam or on the start page (see Messages to
  friends), or waits for them (7 days) and shows with an envelope when they are back; a message to anyone else reaches
  them only while they are online. A message with a slur in it reaches no one, as in the Lobby's chat. Players you block stay blocked: nothing of theirs reaches
  you.
- **Who is on:** Playing now on the start page (under Play) shows how many play on this server now, how many of
  them are in Online mode (in its lobbies or racing) and how many in free roam. Only numbers: no names.
- Turning it off: Online, More online settings, Online mode on the start page (the game then cannot connect).

## 8. When something is wrong

| What you see | What to do |
|---|---|
| "Secure, isolated page" on another PC, `PAGE-NOT-SECURE` | Open the server's `https://` address, not `http`. Only `localhost` works without HTTPS. |
| `PAGE-NOT-ISOLATED` ("Something in this browser changes the page"; before 4 November "not cross-origin isolated"), and with it `MODULE-NOT-ISOLATED` | The page is not opened from the game's server, or something in the browser changes it on the way, most often an extension. A guest or private window shows whether that is it (its saves are gone when it closes); then, in a normal window, turn the extensions off one by one. |
| `PAGE-NO-MEMORY`: "Shared WebAssembly memory is not available" | The browser cannot give the game the memory it needs. Close other tabs, update the browser and restart it. |
| `PAGE-NO-JIT`: "The JavaScript optimizer is off for this site" (or "exnref not supported by the Wasm interpreter") | The browser runs WebAssembly without its compiler here, and the game cannot run that way. Chrome: Settings, Privacy and security, JavaScript optimization and security: allow the site (Android's Advanced Protection turns the optimizer off for every site). Edge: add the site as an exception to Enhanced security. |
| `PAGE-NO-WAITASYNC`: "This browser is too old for the game" | Update the browser (Firefox 145 or newer), or play in Chrome. |
| `PAGE-NO-SIMD`: "This computer's processor is too old for the game" | The game needs WebAssembly SIMD: a PC processor without SSE4.1 (an AMD Phenom II, an Intel Core 2 before Penryn) or a browser too old for it can't compile the game. Update the browser; on such a processor the game can't run. |
| "Graphics (WebGPU)", `GPU-OFF` and the other `GPU-OFF-…` | The browser has no WebGPU, which the game needs. Chrome: update it (on Linux also turn on `chrome://flags/#enable-unsafe-webgpu`). Firefox has it on Windows and on Macs with Apple chips; elsewhere (Linux, Macs with Intel chips) play in Chrome, or set `dom.webgpu.enabled` to true in about:config. Firefox for Android has none yet: play in Chrome. iPhone and iPad: WebGPU comes with iOS 26 and iPadOS 26. `GPU-NOT-SECURE`: see "Secure, isolated page" above. |
| `GPU-ACCEL-OFF` | Chrome uses no graphics at all (it draws WebGL in software, or not at all): "Use graphics acceleration when available" in `chrome://settings/system` is off, or Chrome gave up on the graphics after they crashed. Turn it on and restart Chrome; if it was on, update the graphics driver. |
| `GPU-ADAPTER-LINUX`: Chrome on Linux, while `chrome://gpu` says WebGPU is hardware accelerated | Most likely the Vulkan driver is missing: Chrome runs WebGPU on Vulkan there (the rest of Chrome on OpenGL). `ls /usr/share/vulkan/icd.d/` lists the installed ones (`intel_icd` for Intel, `radeon_icd` for AMD). Install it with `sudo apt install mesa-vulkan-drivers` on Debian and Ubuntu, `sudo dnf install mesa-vulkan-drivers` on Fedora, `vulkan-intel` or `vulkan-radeon` on Arch, then quit Chrome completely and start it again. Chrome has WebGPU on by itself on Linux for Intel graphics (Gen12 and newer) and NVIDIA (Wayland); for other graphics turn on `chrome://flags/#enable-unsafe-webgpu`. If the driver is there, the Dawn Info section further down `chrome://gpu` lists each adapter WebGPU sees and why one is blocked. |
| `GPU-ADAPTER-WIN`: Chrome on Windows | Chrome runs WebGPU on Direct3D 12 there, and older graphics have no Direct3D 12 driver (Intel HD 4000, 4400, 4600 and older, for one): the game cannot run on that computer. The Dawn Info section further down `chrome://gpu` lists each adapter WebGPU sees and why it is blocked; when it lists only "D3D11 backend" adapters, "Blocklisted - D3D11 backend not fully implemented", the graphics have no Direct3D 12. On newer graphics, update the graphics driver from Intel, AMD or NVIDIA, then quit Chrome completely and start it again. |
| `GPU-ADAPTER-WIN-ARM`: Chrome on Windows on ARM (Snapdragon) | Chrome keeps WebGPU behind a flag there: turn on `chrome://flags/#enable-unsafe-webgpu`, then restart Chrome. |
| `GPU-ADAPTER-ANDROID` | Chrome on Android has WebGPU from Android 12 on Qualcomm (Adreno), ARM (Mali) and Intel graphics, and from Android 16 on Imagination (PowerVR). Update Android and Chrome. If that does not help, turn on `chrome://flags/#enable-unsafe-webgpu` (on the phone, type it into Chrome's address bar, or open `chrome://flags` and search for "Unsafe WebGPU"), then restart Chrome: that lifts Chrome's WebGPU blocklist. Samsung's Xclipse (some Galaxy phones) is on it, and the game runs with the flag (a player's Xclipse 540 with Android 16). If the game still does not run with it, it cannot run on that phone yet. |
| `GPU-ADAPTER`, `GPU-ADAPTER-FIREFOX` | The browser would not use the graphics. Restart it; update the graphics driver (on a Mac: macOS) and the browser. `chrome://gpu` in Chrome, about:support (Graphics) in Firefox says why. In Firefox on Windows, graphics without Direct3D 12 cannot run it either. |
| `GPU-ADAPTER-AFTER-LOST` | The graphics stopped during the last game (`GPU-LOST`), and the browser has not given the reloaded page graphics since: not graphics too old. Chrome keeps a site whose graphics hung off them for a while (two minutes); the page asks again every 10 seconds, and Play comes on once they are back. If it stays off, quit the browser completely (every window) and start it again. If the graphics stop again, update the graphics driver; two players' Intel Iris Xe hung this way (`DXGI_ERROR_DEVICE_HUNG` in the log). |
| `GPU-SOFTWARE`: a note that the graphics are software | Chrome gave the game its processor's stand-in for graphics (SwiftShader), which it does with `chrome://flags/#enable-unsafe-webgpu` where it cannot use the graphics: the game runs at ~13 fps. On Linux (a Steam Deck's Chrome, for one), turn on `chrome://flags/#enable-vulkan` and `chrome://flags/#default-angle-vulkan` and restart Chrome (a player's fix: `--enable-features=Vulkan --use-angle=vulkan`). Elsewhere, see `GPU-ACCEL-OFF`. |
| `GPU-NO-BC`: a note about packed textures | Nothing to do: the game plays. These graphics can read neither of the texture formats the game uses, so the page unpacks the textures as the game loads: about 200 MB more memory, and loading screens may pause for a moment. Graphics that can read ASTC (iPhones, iPads, most phones) get no note: most textures are converted to that, about 50 MB more. |
| `GPU-INTEGRATED-FIREFOX`: "Graphics: Intel (integrated)" (or AMD) in Firefox on Windows | Firefox runs the game on the graphics it draws its own windows with, whatever the game asks for. If the computer also has a graphics card, as many laptops do, give Firefox the card: Windows Settings, System, Display, Graphics, Firefox, High performance; then quit Firefox completely and start it again. On a computer with integrated graphics only, nothing changes. Chrome does the same (its `chrome://gpu` names the graphics it uses): the same Windows setting for Chrome, or `chrome://flags/#force-high-performance-gpu`. |
| `GPU-RENDERER`: "The game was stopped" | The graphics did not start: the game cannot go on without them. Restart the browser and press **Play**; if it happens again, update the graphics driver, and download the log (its `[gpu]` lines say why). |
| `GPU-ANDROID-DRIVER`: "Did not start" | The phone's graphics driver refused the game's picture at its first frame (Chrome on some phones with Adreno 6xx graphics; the log's `[gpu] device lost` line says `VK_ERROR_FORMAT_NOT_SUPPORTED` while "checking external image import support"). Every Play ends the same way on that phone: no setting changes it. A system update for the phone (a newer graphics driver) may; another browser on Android has no WebGPU yet. |
| `GPU-LOST`: "The game was stopped" | The graphics stopped during the game (the graphics driver reset, or the browser's graphics process crashed): the game cannot go on without them. Press **Play**: the page reloads, which starts the graphics again (Safari gives a page no graphics after that until it reloads), then **Play** starts the game. Your saves and settings stay. Download the log first if you want to keep it: after the reload, Download log has only a shorter copy of that game's. If the page then says `GPU-ADAPTER-AFTER-LOST`, see that. If it keeps happening, restart the browser and update the graphics driver. |
| "Game module", `MODULE-LOAD`: "The game didn't load" | The game did not load, or the server is not reachable (the log says why). The page tries again by itself, or press **Retry**. If the module is missing, start the server with `web/start.sh`, which builds it. |
| "A new version is out" | During a game: quit when it suits you (F9, **Quit game**). On the start page, press **Reload** or **Play**: the page loads the new version, and your saves and settings stay. Download the log first if you want to keep it: after the reload, Download log has only a shorter copy of that game's. Before any game the page reloads by itself; during a game it says so over the game, and the start page offers it when you quit. |
| "Open elsewhere" | The game runs in another tab of this browser. Switch to it, or close it. |
| "Not loading": "Your antivirus or network is probably blocking the game" | The page's own script never started, 15 seconds after the page opened: an antivirus (Kaspersky flagged the site in November 2026) or a network filter blocks it. Allow `nfsu2.xyz` in it, or try mobile data, then **Reload**. |
| "The game's files didn't load properly" (error code 1 in the first minute) | The game's program file did not load: the browser's copy is damaged, or the network blocks it (the log shows `no PE signature`, or `HTTP 403` for it). **Game**, **Delete game data** (at the tab's end), then **Play**; your saves stay. If it happens again, try another network. |
| `GAME-START`: "Did not start", "The game couldn't start" | Press **Play** again; if it happens again, **Download log** (on the start page) and post the log with the message. "This device doesn't have enough free memory for the game" (the log: "could not allocate memory" in Chrome, "Out of memory" in Safari): the browser would not set aside the game's 1 GB, most often on phones with 2 to 4 GB (a 32-bit Chrome, an iPhone's Home Screen app). Close other apps and reload the page; the log's `[memory]` line says what the browser refused. |
| `STORAGE-NONE`: "This browser window cannot store files" | A guest or private window cannot keep saves: open the page in a normal window. |
| `STORAGE-OLD`: "This browser is too old for the game" | Safari before 26 (iOS 18 with Safari's WebGPU feature flag on, for one) cannot write the game's files. Update to iOS 26, iPadOS 26 or macOS with Safari 26 (Settings, General, Software Update). |
| `SAVES-UNREADABLE`: "Play without saving?", "This browser can't read or write your saves right now" | The browser's storage for the site answered the page with an error (the message names it; Firefox says `UnknownError: Unknown failure`, a full disk among the causes). Nothing of the saves was written or removed. **Play without saving** starts the game anyway: it reads what it can, and nothing from that game is kept (no profile, setting or screenshot). Otherwise restart the browser, make sure the disk has free space, and press **Play** again. If it still fails and the message says your cloud saves have your progress: copy or download your passphrase first (**Cloud saves**; Firefox and Safari keep it only in the site's data), then remove this site's data in the browser's settings (Firefox: Settings, Privacy & Security, Cookies and Site Data, Manage Data; screenshots, covers, this device's settings, the Put back copy and the downloaded game data go too), reload, and enter the passphrase under **Cloud saves**. Otherwise don't remove it (that deletes what the cloud doesn't have) and ask on Discord. Shown over a game: the browser refused a file the game saves to, so a save may not have been kept. |
| `STORAGE-ASK`: the browser asks whether the site may keep its data | Allow it, so that your saves stay when the disk runs low (section 5). |
| `BROWSER-CHROME-OLD`, `BROWSER-FIREFOX-OLD` | A warning: the game may still play. Update the browser (Chrome 140 or newer, Firefox 145 or newer). |
| `BROWSER-OTHER` | A warning: the page does not know this browser (it knows Chrome, Edge, Brave, Opera, Firefox and Safari). It may work when every other check passes. |
| `BROWSER-IPHONE` | Not a problem: on an iPhone the page cannot go full screen, but its copy on the Home Screen can (section 2). |
| `VAULT-…`: a cloud saves problem | The message says what happened: `VAULT-WRONG-KEY` (these saves do not open with this passphrase: check it), `VAULT-TOO-LARGE` (more than the server keeps), `VAULT-HTTP-429` (too many tries: wait a minute), `VAULT-HTTP-503` and `VAULT-HTTP-507` (the server takes no more saves for now), `VAULT-NO-ANSWER` and `VAULT-TIMEOUT` (the server did not answer: try again), `VAULT-LOAD-HALFWAY` (loading the cloud's saves stopped halfway: load again before playing; the copy the page kept of yours is under Put back). |
| No sound | Click the game or press a key. Check the sound setting and the output latency (try "Robust"). |
| Stuck on a loading screen | F9, Quit game; then "Close the game now"; then "Stop the game". When the log ends in `[data]` lines, the game was waiting for its data from the server: it goes on when the data comes. |
| Other players' cars stutter, freeze and jump in an Online or LAN race | The game's own updates go through the player who created the game (the other players' cars also come straight from their games, and small corrections are smoothed out), so let whoever has the steadiest connection (a cable rather than Wi-Fi or mobile) and the fastest computer create it, and keep the game's tab in front. A connection that stops for a second or more still makes cars jump when it comes back. After the race, F9, Download log: its `[racenet]` lines say how each car's updates came (long waits, how many came at once after them) and each player's frame rate. |
| Anything odd | F9, Download log (or "Download log" on the start page after the game ended) and keep the file. It has the game's own log. When the browser stopped the page itself (on an iPhone the game is suddenly gone and the page loads again), the start page says so and Download log starts with that last game's log. After you reload or close the page during a game, Download log has that game's log as well. It names your browser, its version and your system, your graphics chip, and your time zone's offset from UTC. Names (yours, your profiles', crews' and room's, and those of the players you met) and addresses become stand-ins such as `you`, `player-3k9x` and `vlan-7q2m`, the same in every log from that browser, so you can post it as it is. |
| `Port 8080 is in use` when starting | The server already runs; open its address. Or start on another port: `web/start.sh --http-port 9080`. |
| Full screen | The game plays in the browser window. F9, Full screen goes full screen, and holding Esc leaves it (in Firefox, a press). "Full screen on Play" (Game, Display) starts every game full screen. |
